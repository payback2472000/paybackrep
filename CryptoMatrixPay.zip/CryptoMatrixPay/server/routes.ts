import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { db } from "./db";
import { users, payments, systemConfig, matrixQueue, transactions } from "@shared/schema";
import { eq, and, ne, desc } from "drizzle-orm";
import { setupWebSocket, sendNotificationToUser } from "./websocket";
import bcrypt from "bcryptjs";

// Helper function to count activated members in subtree
async function countActivatedMembers(userId: string | null): Promise<number> {
  if (!userId) return 0;
  
  const user = await storage.getUser(userId);
  if (!user || user.accountStatus !== 'active') return 0;
  
  const tree = await storage.getBinaryTreeByUserId(userId);
  if (!tree) return 1; // Just the user itself
  
  const leftCount = await countActivatedMembers(tree.leftChildId);
  const rightCount = await countActivatedMembers(tree.rightChildId);
  
  return 1 + leftCount + rightCount;
}

// Helper function to check and create binary matches for a user
async function checkBinaryMatches(userId: string) {
  const tree = await storage.getBinaryTreeByUserId(userId);
  if (!tree || !tree.isQualified) return;
  
  // Count activated members on each side
  const leftActivated = await countActivatedMembers(tree.leftChildId);
  const rightActivated = await countActivatedMembers(tree.rightChildId);
  
  // Check for 3:3 matches
  while (leftActivated >= 3 && rightActivated >= 3) {
    // Create binary match record
    await storage.createBinaryMatch({
      userId,
      leftUserId: tree.leftChildId,
      rightUserId: tree.rightChildId,
      amount: '1000',
    });
    
    // Create binary income transaction
    await storage.createTransaction({
      userId,
      transactionType: 'binary_income',
      amount: '1000',
      description: '3:3 Binary Match Income',
    });
    
    // Deduct 3 from each side (simplified - in production you'd track this better)
    break; // For now, create one match at a time
  }
}

// Helper function to place user in matrix with FIFO spillover
async function placeInMatrix(userId: string): Promise<{ [key: number]: string | null }> {
  const levelCapacities = [2, 4, 8, 16, 32];
  const uplineIds: { [key: number]: string | null } = {
    1: null,
    2: null,
    3: null,
    4: null,
    5: null,
  };

  // Get matrix queue (FIFO order)
  const queue = await storage.getMatrixQueue();
  
  for (let level = 1; level <= 5; level++) {
    const capacity = levelCapacities[level - 1];
    let uplineFound = false;

    // Find first person in queue who has space at this level
    for (const queueItem of queue) {
      const placements = await storage.getMatrixPlacementsByUserId(queueItem.userId);
      const levelPlacements = placements.filter(p => p.level === level);
      
      if (levelPlacements.length < capacity) {
        // Found upline with space at this level
        const position = levelPlacements.length + 1;
        await storage.createMatrixPlacement({
          userId,
          level,
          position,
          uplineId: queueItem.userId,
          isFilled: false,
        });
        
        uplineIds[level] = queueItem.userId;
        uplineFound = true;
        break;
      }
    }

    // If no upline found (empty queue or all full), place at root
    if (!uplineFound) {
      await storage.createMatrixPlacement({
        userId,
        level,
        position: 1,
        uplineId: null,
        isFilled: false,
      });
      uplineIds[level] = null;
    }
  }

  // Add user to matrix queue
  const queuePosition = queue.length + 1;
  await db.insert(matrixQueue).values({
    userId,
    queuePosition,
  });

  return uplineIds;
}

// Helper function to place user in binary tree
async function placeBinaryTree(userId: string, sponsorId: string, position: 'left' | 'right') {
  // Create binary tree for new user
  await storage.createBinaryTree({
    userId,
    leftChildId: null,
    rightChildId: null,
    leftCount: 0,
    rightCount: 0,
    isQualified: false,
  });

  // Get or create sponsor's binary tree
  let sponsorTree = await storage.getBinaryTreeByUserId(sponsorId);
  if (!sponsorTree) {
    await storage.createBinaryTree({
      userId: sponsorId,
      leftChildId: null,
      rightChildId: null,
      leftCount: 0,
      rightCount: 0,
      isQualified: false,
    });
    sponsorTree = await storage.getBinaryTreeByUserId(sponsorId);
  }

  // Place user in sponsor's tree
  if (position === 'left') {
    await storage.updateBinaryTree(sponsorId, {
      leftChildId: userId,
      leftCount: (sponsorTree.leftCount || 0) + 1,
    });
  } else {
    await storage.updateBinaryTree(sponsorId, {
      rightChildId: userId,
      rightCount: (sponsorTree.rightCount || 0) + 1,
    });
  }

  // Update sponsor's qualification status (needs 1+ left and 1+ right)
  const updatedTree = await storage.getBinaryTreeByUserId(sponsorId);
  if (updatedTree.leftCount > 0 && updatedTree.rightCount > 0 && !updatedTree.isQualified) {
    await storage.updateBinaryTree(sponsorId, { isQualified: true });
  }

  return sponsorId; // Return sponsor as binary upline for payment
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup Replit Auth
  await setupAuth(app);
  
  // Admin login with email/password
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
      }
      
      const user = await storage.getUserByEmail(email);
      
      if (!user || !user.isAdmin) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      if (!user.password) {
        return res.status(401).json({ error: "Admin account not set up. Please use admin setup." });
      }
      
      const passwordMatch = await bcrypt.compare(password, user.password);
      
      if (!passwordMatch) {
        return res.status(401).json({ error: "Invalid credentials" });
      }
      
      // Set admin session
      (req.session as any).adminUser = {
        id: user.id,
        email: user.email,
        isAdmin: true,
      };
      
      await new Promise((resolve, reject) => {
        req.session.save((err) => err ? reject(err) : resolve(undefined));
      });
      
      res.json({ success: true, user: { id: user.id, email: user.email, firstName: user.firstName, lastName: user.lastName } });
    } catch (error) {
      console.error("Admin login error:", error);
      res.status(500).json({ error: "Login failed" });
    }
  });
  
  // Admin logout
  app.post("/api/admin/logout", async (req, res) => {
    try {
      delete (req.session as any).adminUser;
      await new Promise((resolve, reject) => {
        req.session.save((err) => err ? reject(err) : resolve(undefined));
      });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Logout failed" });
    }
  });
  
  // Check admin session
  app.get("/api/admin/session", async (req, res) => {
    const adminUser = (req.session as any).adminUser;
    if (adminUser) {
      res.json({ loggedIn: true, user: adminUser });
    } else {
      res.json({ loggedIn: false });
    }
  });
  
  // Admin setup (first time setup or password change)
  app.post("/api/admin/setup", async (req, res) => {
    try {
      const { email, password, setupKey } = req.body;
      
      // Simple setup key check (in production, use env variable or more secure method)
      if (setupKey !== "ADMIN_SETUP_2024") {
        return res.status(403).json({ error: "Invalid setup key" });
      }
      
      if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
      }
      
      if (password.length < 8) {
        return res.status(400).json({ error: "Password must be at least 8 characters" });
      }
      
      const hashedPassword = await bcrypt.hash(password, 10);
      
      // Check if user exists
      let user = await storage.getUserByEmail(email);
      
      if (user) {
        // Update existing user to admin
        await storage.updateUser(user.id, {
          password: hashedPassword,
          isAdmin: true,
        });
      } else {
        // Create new admin user
        user = await storage.createUser({
          email,
          password: hashedPassword,
          isAdmin: true,
          firstName: "Admin",
          lastName: "User",
          phone: "",
        });
      }
      
      res.json({ success: true, message: "Admin account created successfully" });
    } catch (error) {
      console.error("Admin setup error:", error);
      res.status(500).json({ error: "Setup failed" });
    }
  });
  
  // Store referral info in session
  app.post("/api/referral/store", async (req, res) => {
    try {
      const { sponsorId, position } = req.body;
      if (sponsorId && position && (position === 'left' || position === 'right')) {
        (req.session as any).referralInfo = { sponsorId, position };
        await new Promise((resolve, reject) => {
          req.session.save((err) => err ? reject(err) : resolve(undefined));
        });
        res.json({ success: true });
      } else {
        res.status(400).json({ error: "Invalid referral parameters" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to store referral info" });
    }
  });
  
  // Get authenticated user
  app.get("/api/auth/user", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const email = req.user.claims.email || `${userId}@test.com`;
      const firstName = req.user.claims.first_name || "User";
      const lastName = req.user.claims.last_name || "";
      
      // Check for referral info in session
      const referralInfo = (req.session as any).referralInfo;
      
      // Upsert user from auth claims
      const user = await storage.upsertUser({
        id: userId,
        email,
        firstName,
        lastName,
        phone: "",
        isAdmin: false,
        sponsorId: referralInfo?.sponsorId || null,
        position: referralInfo?.position || null,
      });
      
      // Check if user has activation payments, if not create them
      const existingPayments = await storage.getPaymentsByUserId(userId);
      if (existingPayments.length === 0) {
        // Create activation payments totaling ₹5000
        // ₹1000 referral + ₹1000 binary + ₹2500 matrix (5 levels × ₹500) + ₹500 system fee
        
        // 1. Referral payment (₹1000 = 10 USDT) - receiverId is sponsor if exists
        await storage.createPayment({
          userId,
          paymentType: 'referral',
          amount: '1000',
          cryptoAmount: '10.00145', // Unique USDT amount for auto-verification
          receiverId: user.sponsorId || null,
          status: 'unpaid',
        });
        
        // Create referral relationship and binary tree placement if sponsor exists
        if (user.sponsorId && user.position) {
          await storage.createReferral({
            sponsorId: user.sponsorId,
            referredId: userId,
            position: user.position,
          });
          
          // Place in binary tree (still maintain tree structure)
          await placeBinaryTree(userId, user.sponsorId, user.position);
        }
        
        // 2. Binary payment (₹1000 = 10 USDT) - FIFO Queue System
        // Get the next person in the binary queue (first in line)
        const nextInQueue = await storage.getNextInBinaryQueue();
        
        let binaryReceiverId = null;
        let binaryAdminAccountId = null;
        let needsAdminConfirmation = false;
        
        if (nextInQueue) {
          // Someone in queue - normal flow
          binaryReceiverId = nextInQueue.userId;
        } else {
          // Queue is empty - route to admin account
          const adminAccount = await storage.getRandomAdminAccount();
          if (adminAccount) {
            binaryAdminAccountId = adminAccount.id; // Admin account ID
            needsAdminConfirmation = true;
          }
        }
        
        await storage.createPayment({
          userId,
          paymentType: 'binary',
          amount: '1000',
          cryptoAmount: '10.00287', // Unique USDT amount for auto-verification
          receiverId: binaryReceiverId,
          adminAccountId: binaryAdminAccountId,
          status: 'unpaid',
          needsAdminConfirmation,
        });
        
        // Add new user to the end of the binary queue
        await storage.addToBinaryQueue(userId);
        
        // 3-7. Matrix level payments (₹500 each for 5 levels = ₹2500)
        // Place user in matrix and get upline IDs for each level
        const matrixUplines = await placeInMatrix(userId);
        
        await storage.createPayment({
          userId,
          paymentType: 'matrix_level_1',
          amount: '500',
          cryptoAmount: '5.00123', // Unique USDT amount
          receiverId: matrixUplines[1],
          status: 'unpaid',
        });
        await storage.createPayment({
          userId,
          paymentType: 'matrix_level_2',
          amount: '500',
          cryptoAmount: '5.00234', // Unique USDT amount
          receiverId: matrixUplines[2],
          status: 'unpaid',
        });
        await storage.createPayment({
          userId,
          paymentType: 'matrix_level_3',
          amount: '500',
          cryptoAmount: '5.00356', // Unique USDT amount
          receiverId: matrixUplines[3],
          status: 'unpaid',
        });
        await storage.createPayment({
          userId,
          paymentType: 'matrix_level_4',
          amount: '500',
          cryptoAmount: '5.00478', // Unique USDT amount
          receiverId: matrixUplines[4],
          status: 'unpaid',
        });
        await storage.createPayment({
          userId,
          paymentType: 'matrix_level_5',
          amount: '500',
          cryptoAmount: '5.00592', // Unique USDT amount
          receiverId: matrixUplines[5],
          status: 'unpaid',
        });
        
        // 8. System fee payment (₹500 = 5 USDT) - goes to admin account
        const systemFeeAdminAccount = await storage.getRandomAdminAccount();
        await storage.createPayment({
          userId,
          paymentType: 'system_fee',
          amount: '500',
          cryptoAmount: '5.00619', // Unique USDT amount
          receiverId: null, // No user receiver for system fees
          adminAccountId: systemFeeAdminAccount?.id || null,
          status: 'unpaid',
          needsAdminConfirmation: true,
        });
      }
      
      res.json(user);
    } catch (error) {
      console.error("Failed to fetch/create user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // User profile update
  app.put("/api/profile", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const updated = await storage.updateUser(userId, req.body);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to update profile" });
    }
  });

  // Dashboard stats
  app.get("/api/stats", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserStats(userId);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  // Get user's payments
  app.get("/api/payments", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userPayments = await storage.getPaymentsByUserId(userId);
      res.json(userPayments);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch payments" });
    }
  });

  // Submit payment
  app.post("/api/payments/submit", isAuthenticated, async (req: any, res) => {

    try {
      const { paymentId, transactionId, transactionHash, proofUrl, method } = req.body;
      
      // For USDT, transactionId is the hash
      const txHash = method === 'usdt' ? (transactionHash || transactionId) : transactionId;
      
      // For USDT BEP-20, verify on BSC blockchain first
      if (method === 'usdt' && txHash) {
        try {
          // Get payment details for amount verification
          const [payment] = await db.select().from(payments).where(eq(payments.id, paymentId));
          
          // BscScan API - Get transaction receipt (no API key needed for basic queries)
          const response = await fetch(
            `https://api.bscscan.com/api?module=proxy&action=eth_getTransactionReceipt&txhash=${txHash}`
          );
          
          if (response.ok) {
            const data = await response.json();
            const receipt = data.result;
            
            if (receipt && receipt.status) {
              // Check if transaction was successful (status = 0x1 means success)
              const isSuccess = receipt.status === '0x1';
              const isConfirmed = receipt.blockNumber !== undefined;
              
              // Verify it's a USDT transfer (contract address: 0x55d398326f99059fF775485246999027B3197955)
              const USDT_CONTRACT = '0x55d398326f99059ff775485246999027b3197955';
              const hasUSDTTransfer = receipt.logs?.some((log: any) => 
                log.address.toLowerCase() === USDT_CONTRACT
              );
              
              if (isConfirmed && isSuccess && hasUSDTTransfer) {
                // Check if payment needs admin confirmation (system fee or binary to admin)
                if (payment.needsAdminConfirmation) {
                  // Payment needs admin review - don't auto-confirm even with USDT
                  await storage.updatePayment(paymentId, {
                    transactionId: txHash,
                    transactionHash: txHash,
                    proofUrl,
                    paymentMethod: method,
                    status: 'pending_confirmation',
                    needsAdminConfirmation: true, // Preserve flag
                  });
                  
                  return res.json({ 
                    success: true, 
                    verified: true, 
                    network: 'BEP-20',
                    message: 'USDT verified on blockchain - awaiting admin confirmation'
                  });
                }
                
                // Auto-confirm USDT payment (normal payments)
                await storage.updatePayment(paymentId, {
                  transactionId: txHash,
                  transactionHash: txHash,
                  proofUrl,
                  paymentMethod: method,
                  status: 'confirmed',
                  confirmedAt: new Date(),
                });
                
                // Trigger income distribution immediately
                
                // Create income transaction for receiver
                if (payment.receiverId) {
                  await storage.createTransaction({
                    userId: payment.receiverId,
                    transactionType: payment.paymentType.includes('referral') ? 'referral_income' : 
                                    payment.paymentType.includes('binary') ? 'binary_income' : 'matrix_income',
                    amount: payment.amount,
                    fromUserId: payment.userId,
                    description: `${payment.paymentType} payment confirmed (USDT BEP-20)`,
                  });
                  
                  // Remove receiver from binary queue if this was a binary payment (FIFO system)
                  if (payment.paymentType === 'binary') {
                    await storage.removeFromBinaryQueue(payment.receiverId);
                  }
                  
                  // Notify receiver
                  const currentUser = await storage.getUser(req.user.claims.sub);
                  const receiverNotification = {
                    userId: payment.receiverId,
                    title: "USDT BEP-20 Payment Confirmed",
                    message: `Received ₹${payment.amount} from ${currentUser?.firstName} (BSC blockchain verified)`,
                  };
                  await storage.createNotification(receiverNotification);
                  sendNotificationToUser(payment.receiverId, {
                    ...receiverNotification,
                    type: 'income_received',
                  });
                }
                
                return res.json({ success: true, verified: true, network: 'BEP-20' });
              }
            }
          }
          
          // If verification fails, mark as verifying
          // Check if payment needs admin confirmation first
          const needsAdmin = payment.needsAdminConfirmation;
          
          await storage.updatePayment(paymentId, {
            transactionId: txHash,
            transactionHash: txHash,
            proofUrl,
            paymentMethod: method,
            status: needsAdmin ? 'pending_confirmation' : 'verifying',
            needsAdminConfirmation: needsAdmin, // Preserve the flag
          });
          
          return res.json({ success: true, verified: false, message: 'Transaction not yet confirmed on BSC blockchain' });
        } catch (verifyError) {
          console.error('USDT BEP-20 verification error:', verifyError);
          // Fall back to manual verification
        }
      }
      
      // For non-USDT payments or if USDT verification failed
      // Check if payment needs admin confirmation (system fee or binary when queue empty)
      const [paymentForCheck] = await db.select().from(payments).where(eq(payments.id, paymentId));
      const needsAdmin = paymentForCheck.needsAdminConfirmation;
      
      await storage.updatePayment(paymentId, {
        transactionId,
        proofUrl,
        paymentMethod: method,
        status: needsAdmin ? 'pending_confirmation' : 'verifying',
        needsAdminConfirmation: needsAdmin, // Preserve the flag
      });

      // Create notification for receiver
      const [payment] = await db.select().from(payments).where(eq(payments.id, paymentId));
      if (payment.receiverId) {
        const currentUser = await storage.getUser(req.user.claims.sub);
        await storage.createNotification({
          userId: payment.receiverId,
          title: "Payment Received",
          message: `New payment of ₹${payment.amount} from ${currentUser?.firstName}`,
        });
      }

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to submit payment" });
    }
  });

  // Get pending confirmations
  app.get("/api/confirmations/pending", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const pendingPayments = await storage.getPendingConfirmations(userId);
      
      // Join with sender user data
      const paymentsWithSender = await Promise.all(
        pendingPayments.map(async (payment) => {
          const sender = await storage.getUser(payment.userId);
          return { ...payment, sender };
        })
      );

      res.json(paymentsWithSender);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch confirmations" });
    }
  });

  // Confirm payment
  app.post("/api/confirmations/:id/confirm", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const [payment] = await db.select().from(payments).where(eq(payments.id, id));
      
      if (!payment || payment.receiverId !== userId) {
        return res.status(403).json({ error: "Unauthorized" });
      }

      // Update payment status to confirmed
      await storage.updatePayment(id, {
        status: 'confirmed',
        confirmedAt: new Date(),
      });

      // Create income transaction for receiver
      await storage.createTransaction({
        userId,
        transactionType: payment.paymentType.includes('referral') ? 'referral_income' : 
                        payment.paymentType.includes('binary') ? 'binary_income' : 'matrix_income',
        amount: payment.amount,
        fromUserId: payment.userId,
        description: `${payment.paymentType} payment confirmed`,
      });

      // Remove receiver from binary queue if this was a binary payment (FIFO system)
      if (payment.paymentType === 'binary') {
        await storage.removeFromBinaryQueue(userId);
      }

      // Notify sender (database + WebSocket)
      const senderNotification = {
        userId: payment.userId,
        title: "Payment Confirmed",
        message: `Your payment of ₹${payment.amount} has been confirmed`,
      };
      await storage.createNotification(senderNotification);
      sendNotificationToUser(payment.userId, {
        ...senderNotification,
        type: 'payment_confirmed',
      });

      // Check if user is fully activated (all 7 payments confirmed)
      const userPayments = await storage.getPaymentsByUserId(payment.userId);
      const allConfirmed = userPayments.every(p => p.status === 'confirmed');
      
      if (allConfirmed && userPayments.length === 7) {
        // Activate user account
        await storage.updateUser(payment.userId, {
          accountStatus: 'active',
        });

        // Notify user of activation (database + WebSocket)
        const activationNotification = {
          userId: payment.userId,
          title: "Account Activated!",
          message: "Congratulations! Your account is now fully activated. You can start earning income.",
        };
        await storage.createNotification(activationNotification);
        sendNotificationToUser(payment.userId, {
          ...activationNotification,
          type: 'account_activated',
        });

        // Trigger binary matching check for user's uplines
        const user = await storage.getUser(payment.userId);
        if (user?.sponsorId) {
          // Check matches for sponsor and their uplines
          await checkBinaryMatches(user.sponsorId);
          
          // Get sponsor's sponsor and check them too (up to 3 levels)
          const sponsor = await storage.getUser(user.sponsorId);
          if (sponsor?.sponsorId) {
            await checkBinaryMatches(sponsor.sponsorId);
          }
        }
      }

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to confirm payment" });
    }
  });

  // Reject payment (create dispute)
  app.post("/api/confirmations/:id/reject", isAuthenticated, async (req: any, res) => {
    try {
      const { id } = req.params;
      const userId = req.user.claims.sub;
      const [payment] = await db.select().from(payments).where(eq(payments.id, id));
      
      if (!payment || payment.receiverId !== userId) {
        return res.status(403).json({ error: "Unauthorized" });
      }

      await storage.updatePayment(id, { status: 'disputed' });
      
      await storage.createDispute({
        paymentId: id,
        senderId: payment.userId,
        receiverId: userId,
        reason: "Payment not received or incorrect",
      });

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to reject payment" });
    }
  });

  // Binary tree data
  app.get("/api/binary", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const tree = await storage.getBinaryTreeByUserId(userId);
      const transactions = await storage.getTransactionsByUserId(userId);
      const matches = await storage.getBinaryMatchesByUserId(userId);
      const binaryIncome = transactions
        .filter(t => t.transactionType === 'binary_income')
        .reduce((sum, t) => sum + parseFloat(t.amount.toString()), 0);

      const stats = {
        totalIncome: binaryIncome,
        leftCount: tree?.leftCount || 0,
        rightCount: tree?.rightCount || 0,
        pendingIncome: 0,
        isQualified: tree?.isQualified || false,
      };

      // Build global binary queue - all users ordered by join date
      const allUsers = await db
        .select({
          userId: users.id,
          firstName: users.firstName,
          lastName: users.lastName,
          email: users.email,
          joinedAt: users.createdAt,
        })
        .from(users)
        .orderBy(users.createdAt);

      // Get binary tree data for each user
      const queueData = await Promise.all(
        allUsers.map(async (user) => {
          const userTree = await storage.getBinaryTreeByUserId(user.userId);
          const displayName = user.firstName && user.lastName 
            ? `${user.firstName} ${user.lastName}` 
            : user.email || user.userId.slice(0, 8);
          
          return {
            userId: user.userId,
            name: displayName,
            joinedAt: user.joinedAt,
            leftCount: userTree?.leftCount || 0,
            rightCount: userTree?.rightCount || 0,
            isQualified: userTree?.isQualified || false,
            isCurrentUser: user.userId === userId,
          };
        })
      );

      res.json({
        tree,
        stats,
        matches,
        queue: queueData,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch binary data" });
    }
  });

  // Matrix data
  app.get("/api/matrix", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const placements = await storage.getMatrixPlacementsByUserId(userId);
      const transactions = await storage.getTransactionsByUserId(userId);
      const matrixIncome = transactions
        .filter(t => t.transactionType === 'matrix_income')
        .reduce((sum, t) => sum + parseFloat(t.amount.toString()), 0);

      const stats = {
        totalIncome: matrixIncome,
        totalMembers: placements.length,
      };

      const levels = [1, 2, 3, 4, 5].map(level => {
        const levelPlacements = placements.filter(p => p.level === level);
        const capacities = [2, 4, 8, 16, 32];
        return {
          level,
          capacity: capacities[level - 1],
          filled: levelPlacements.length,
          members: levelPlacements,
        };
      });

      res.json({
        stats,
        levels,
        queue: [],
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch matrix data" });
    }
  });

  // Sponsor income
  app.get("/api/sponsor", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const referralsData = await storage.getReferralsByUserId(userId);
      const transactions = await storage.getTransactionsByUserId(userId);
      const sponsorTransactions = transactions.filter(t => t.transactionType === 'referral_income');
      const sponsorIncome = sponsorTransactions.reduce((sum, t) => sum + parseFloat(t.amount.toString()), 0);

      const leftCount = referralsData.filter(r => r.position === 'left').length;
      const rightCount = referralsData.filter(r => r.position === 'right').length;

      res.json({
        totalIncome: sponsorIncome,
        totalReferrals: referralsData.length,
        leftCount,
        rightCount,
        transactions: sponsorTransactions,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch sponsor data" });
    }
  });

  // All transactions
  app.get("/api/transactions", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const transactions = await storage.getTransactionsByUserId(userId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch transactions" });
    }
  });

  // ADMIN ROUTES
  const checkAdmin = async (req: any, res: any, next: any) => {
    // Check for admin session first (email/password login)
    const adminSession = (req.session as any).adminUser;
    if (adminSession && adminSession.isAdmin) {
      req.adminUser = adminSession;
      return next();
    }
    
    // Fall back to Replit Auth check
    const userId = req.user?.claims?.sub;
    if (!userId) {
      return res.status(401).send("Unauthorized");
    }
    const user = await storage.getUser(userId);
    if (!user?.isAdmin) {
      return res.status(403).send("Forbidden");
    }
    req.adminUser = { id: user.id, email: user.email, isAdmin: true };
    next();
  };

  app.get("/api/admin/disputes", checkAdmin, async (req: any, res) => {
    try {
      const disputes = await storage.getDisputes();
      res.json(disputes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch disputes" });
    }
  });

  app.post("/api/admin/disputes/:id/resolve", checkAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { resolution } = req.body;
      
      await storage.resolveDispute(id, resolution);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to resolve dispute" });
    }
  });

  app.get("/api/admin/users", checkAdmin, async (req: any, res) => {
    try {
      const allUsers = await storage.getAllUsers();
      res.json(allUsers);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  app.get("/api/admin/users/:id/transactions", checkAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      const transactions = await storage.getTransactionsByUserId(id);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user transactions" });
    }
  });

  app.post("/api/admin/users/:id/notes", checkAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      const { note } = req.body;
      const adminId = req.adminUser?.id || req.user?.claims?.sub;
      
      await storage.createAdminNote({
        userId: id,
        note,
        createdBy: adminId,
      });
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to add note" });
    }
  });

  app.get("/api/admin/config", checkAdmin, async (req: any, res) => {
    try {
      let config = await storage.getSystemConfig();
      
      // Create default config if it doesn't exist
      if (!config) {
        await db.insert(systemConfig).values({
          id: 'system',
          referralIncome: '1000',
          binaryIncome: '1000',
          matrixIncomePerLevel: '500',
          adminFeePerUser: '500',
          paymentTimerMinutes: 1440,
          totalActivationFee: '5000',
        });
        config = await storage.getSystemConfig();
      }
      
      res.json(config);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch config" });
    }
  });

  app.put("/api/admin/config", checkAdmin, async (req: any, res) => {
    try {
      await storage.updateSystemConfig(req.body);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update config" });
    }
  });

  // Admin payment accounts management
  app.get("/api/admin/payment-accounts", checkAdmin, async (req: any, res) => {
    try {
      const accounts = await storage.getAdminAccounts();
      res.json(accounts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch admin accounts" });
    }
  });

  app.post("/api/admin/payment-accounts", checkAdmin, async (req: any, res) => {
    try {
      const account = await storage.createAdminAccount(req.body);
      res.json(account);
    } catch (error) {
      res.status(500).json({ error: "Failed to create admin account" });
    }
  });

  app.put("/api/admin/payment-accounts/:id", checkAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.updateAdminAccount(id, req.body);
      const updatedAccount = await storage.getAdminAccount(id);
      res.json({ success: true, account: updatedAccount });
    } catch (error) {
      console.error("Error updating admin account:", error);
      res.status(500).json({ error: "Failed to update admin account" });
    }
  });

  app.delete("/api/admin/payment-accounts/:id", checkAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      await storage.deleteAdminAccount(id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete admin account" });
    }
  });

  // Admin payment confirmations - Get payments needing admin confirmation
  app.get("/api/admin/payment-confirmations", checkAdmin, async (req: any, res) => {
    try {
      const pendingPayments = await db
        .select({
          id: payments.id,
          userId: payments.userId,
          amount: payments.amount,
          paymentType: payments.paymentType,
          status: payments.status,
          receiverId: payments.receiverId,
          proofUrl: payments.proofUrl,
          paymentMethod: payments.paymentMethod,
          transactionHash: payments.transactionHash,
          createdAt: payments.createdAt,
          userFirstName: users.firstName,
          userLastName: users.lastName,
          userEmail: users.email,
        })
        .from(payments)
        .leftJoin(users, eq(payments.userId, users.id))
        .where(
          and(
            eq(payments.needsAdminConfirmation, true),
            ne(payments.status, 'confirmed')
          )
        )
        .orderBy(desc(payments.createdAt));

      res.json(pendingPayments);
    } catch (error) {
      console.error("Error fetching admin payment confirmations:", error);
      res.status(500).json({ error: "Failed to fetch payment confirmations" });
    }
  });

  // Admin payment confirmation - Confirm a payment
  app.post("/api/admin/payment-confirmations/:id/confirm", checkAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      
      // Get the payment
      const [payment] = await db.select().from(payments).where(eq(payments.id, id));
      
      if (!payment) {
        return res.status(404).json({ error: "Payment not found" });
      }

      if (!payment.needsAdminConfirmation) {
        return res.status(400).json({ error: "This payment doesn't need admin confirmation" });
      }

      // Update payment status to confirmed
      await db.update(payments)
        .set({
          status: 'confirmed',
          needsAdminConfirmation: false,
          confirmedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(payments.id, id));

      // For admin payments, just increment admin account usage
      // (Admin income is tracked separately in admin_accounts table, not in transactions)
      if (payment.adminAccountId) {
        await storage.incrementAdminAccountUsage(payment.adminAccountId);
      }

      // Notify user their payment was confirmed
      const notification = {
        userId: payment.userId,
        title: "Payment Confirmed by Admin",
        message: `Your ₹${payment.amount} ${payment.paymentType} payment has been confirmed`,
        type: 'success' as const,
      };
      await storage.createNotification(notification);

      // Send WebSocket notification
      const wsService = (req as any).app.get('wsService');
      wsService?.sendToUser(payment.userId, {
        type: 'payment_confirmed',
        data: { paymentId: payment.id },
      });

      res.json({ success: true, payment });
    } catch (error) {
      console.error("Error confirming admin payment:", error);
      res.status(500).json({ error: "Failed to confirm payment" });
    }
  });

  // Admin system fee confirmations - Get pending system fees
  app.get("/api/admin/system-fee-confirmations", checkAdmin, async (req: any, res) => {
    try {
      const pendingSystemFees = await db.select()
        .from(payments)
        .where(
          and(
            eq(payments.paymentType, 'system_fee'),
            eq(payments.needsAdminConfirmation, true),
            ne(payments.status, 'confirmed')
          )
        )
        .orderBy(desc(payments.createdAt));

      res.json(pendingSystemFees);
    } catch (error) {
      console.error("Error fetching system fee confirmations:", error);
      res.status(500).json({ error: "Failed to fetch system fee confirmations" });
    }
  });

  // Admin system fee confirmation - Confirm a system fee payment
  app.post("/api/admin/system-fee-confirmations/:id/confirm", checkAdmin, async (req: any, res) => {
    try {
      const { id } = req.params;
      
      // Get the payment
      const [payment] = await db.select().from(payments).where(eq(payments.id, id));
      
      if (!payment) {
        return res.status(404).json({ error: "Payment not found" });
      }

      if (payment.paymentType !== 'system_fee') {
        return res.status(400).json({ error: "This is not a system fee payment" });
      }

      if (!payment.needsAdminConfirmation) {
        return res.status(400).json({ error: "This payment doesn't need admin confirmation" });
      }

      // Update payment status to confirmed
      await db.update(payments)
        .set({
          status: 'confirmed',
          needsAdminConfirmation: false,
          confirmedAt: new Date(),
          updatedAt: new Date(),
        })
        .where(eq(payments.id, id));

      // For admin payments, just increment admin account usage
      // (Admin income is tracked separately in admin_accounts table, not in transactions)
      if (payment.adminAccountId) {
        await storage.incrementAdminAccountUsage(payment.adminAccountId);
      }

      // Notify user their payment was confirmed
      const notification = {
        userId: payment.userId,
        title: "System Fee Confirmed",
        message: `Your ₹${payment.amount} system fee has been confirmed`,
        type: 'success' as const,
      };
      await storage.createNotification(notification);

      // Send WebSocket notification
      const wsService = (req as any).app.get('wsService');
      wsService?.sendToUser(payment.userId, {
        type: 'payment_confirmed',
        data: { paymentId: payment.id },
      });

      res.json({ success: true, payment });
    } catch (error) {
      console.error("Error confirming system fee:", error);
      res.status(500).json({ error: "Failed to confirm system fee" });
    }
  });

  // Admin dashboard analytics
  app.get("/api/admin/analytics", checkAdmin, async (req: any, res) => {
    try {
      const allUsers = await storage.getAllUsers();
      const allPayments = await storage.getAllPayments();
      const disputes = await storage.getDisputes();
      
      const totalUsers = allUsers.length;
      const activeUsers = allUsers.filter((u: any) => u.accountStatus === 'active').length;
      const pendingActivationUsers = allUsers.filter((u: any) => u.accountStatus === 'pending_activation').length;
      
      const totalPayments = allPayments.length;
      const confirmedPayments = allPayments.filter((p: any) => p.status === 'confirmed').length;
      const pendingPayments = allPayments.filter((p: any) => p.status === 'pending').length;
      const disputedPayments = disputes.length;
      
      const totalRevenue = allPayments
        .filter((p: any) => p.status === 'confirmed' && p.type === 'admin_fee')
        .reduce((sum: number, p: any) => sum + parseFloat(p.amount), 0);

      res.json({
        users: {
          total: totalUsers,
          active: activeUsers,
          pendingActivation: pendingActivationUsers,
        },
        payments: {
          total: totalPayments,
          confirmed: confirmedPayments,
          pending: pendingPayments,
          disputed: disputedPayments,
        },
        revenue: {
          total: totalRevenue,
        },
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch analytics" });
    }
  });

  const httpServer = createServer(app);
  
  // Setup WebSocket server
  setupWebSocket(httpServer);
  
  return httpServer;
}
