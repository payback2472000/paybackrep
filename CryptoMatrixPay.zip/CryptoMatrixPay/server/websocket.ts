import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';

// Store active WebSocket connections by user ID
const userConnections = new Map<string, WebSocket[]>();

export function setupWebSocket(server: Server) {
  const wss = new WebSocketServer({ 
    server,
    path: '/ws',
  });

  wss.on('connection', (ws: WebSocket, req) => {
    let userId: string | null = null;

    ws.on('message', (message: string) => {
      try {
        const data = JSON.parse(message.toString());
        
        if (data.type === 'auth' && data.userId) {
          const authUserId = data.userId as string;
          userId = authUserId;
          
          // Store this connection for the user
          if (!userConnections.has(authUserId)) {
            userConnections.set(authUserId, []);
          }
          userConnections.get(authUserId)?.push(ws);

          // Send confirmation
          ws.send(JSON.stringify({ type: 'auth_success' }));
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      if (userId) {
        // Remove this connection
        const connections = userConnections.get(userId);
        if (connections) {
          const index = connections.indexOf(ws);
          if (index > -1) {
            connections.splice(index, 1);
          }
          if (connections.length === 0) {
            userConnections.delete(userId);
          }
        }
      }
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
    });
  });
}

// Send notification to a specific user
export function sendNotificationToUser(userId: string, notification: any) {
  const connections = userConnections.get(userId);
  if (connections && connections.length > 0) {
    const message = JSON.stringify({
      type: 'notification',
      data: notification,
    });

    connections.forEach(ws => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(message);
      }
    });
  }
}

// Broadcast to all connected users
export function broadcastNotification(notification: any) {
  const message = JSON.stringify({
    type: 'notification',
    data: notification,
  });

  userConnections.forEach((connections) => {
    connections.forEach(ws => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(message);
      }
    });
  });
}
