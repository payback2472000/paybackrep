import { db } from "./db";
import { eq, and, or, desc, sql } from "drizzle-orm";
import {
  users,
  referrals,
  payments,
  binaryTree,
  binaryMatches,
  binaryQueue,
  matrixPlacements,
  matrixQueue,
  transactions,
  notifications,
  disputes,
  systemConfig,
  adminNotes,
  adminAccounts,
  type User,
  type UpsertUser,
  type InsertReferral,
  type InsertPayment,
  type InsertTransaction,
  type InsertNotification,
  type InsertDispute,
  type InsertAdminNote,
  type SystemConfig,
} from "@shared/schema";

export interface IStorage {
  // Users (MANDATORY for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: UpsertUser): Promise<User>;
  updateUser(id: string, data: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;

  // Referrals
  createReferral(data: InsertReferral): Promise<void>;
  getReferralsByUserId(userId: string): Promise<any[]>;

  // Payments
  createPayment(data: InsertPayment): Promise<any>;
  getPaymentsByUserId(userId: string): Promise<any[]>;
  getPendingConfirmations(userId: string): Promise<any[]>;
  getAllPayments(): Promise<any[]>;
  updatePayment(id: string, data: Partial<any>): Promise<void>;

  // Binary Tree
  getBinaryTreeByUserId(userId: string): Promise<any>;
  createBinaryTree(data: any): Promise<void>;
  updateBinaryTree(userId: string, data: any): Promise<void>;
  createBinaryMatch(data: any): Promise<void>;
  getBinaryMatchesByUserId(userId: string): Promise<any[]>;

  // Matrix
  getMatrixPlacementsByUserId(userId: string): Promise<any[]>;
  createMatrixPlacement(data: any): Promise<void>;
  getMatrixQueue(): Promise<any[]>;

  // Binary Queue (FIFO)
  getBinaryQueue(): Promise<any[]>;
  addToBinaryQueue(userId: string): Promise<void>;
  removeFromBinaryQueue(userId: string): Promise<void>;
  getNextInBinaryQueue(): Promise<any | undefined>;

  // Transactions
  createTransaction(data: InsertTransaction): Promise<void>;
  getTransactionsByUserId(userId: string): Promise<any[]>;

  // Notifications
  createNotification(data: InsertNotification): Promise<void>;
  getNotificationsByUserId(userId: string): Promise<any[]>;

  // Disputes
  createDispute(data: InsertDispute): Promise<void>;
  getDisputes(): Promise<any[]>;
  resolveDispute(id: string, resolution: string): Promise<void>;

  // System Config
  getSystemConfig(): Promise<SystemConfig | undefined>;
  updateSystemConfig(data: Partial<SystemConfig>): Promise<void>;

  // Admin Notes
  createAdminNote(data: InsertAdminNote): Promise<void>;
  getAdminNotesByUserId(userId: string): Promise<any[]>;

  // Admin Accounts
  createAdminAccount(data: any): Promise<any>;
  getAdminAccount(id: string): Promise<any | undefined>;
  getAdminAccounts(): Promise<any[]>;
  getActiveAdminAccounts(): Promise<any[]>;
  getRandomAdminAccount(): Promise<any | undefined>;
  updateAdminAccount(id: string, data: any): Promise<void>;
  deleteAdminAccount(id: string): Promise<void>;
  incrementAdminAccountUsage(id: string): Promise<void>;

  // Stats
  getUserStats(userId: string): Promise<any>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(userData: UpsertUser): Promise<User> {
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }

  async updateUser(id: string, data: Partial<User>): Promise<User | undefined> {
    const [updated] = await db.update(users).set({ ...data, updatedAt: new Date() }).where(eq(users.id, id)).returning();
    return updated;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async createReferral(data: InsertReferral): Promise<void> {
    await db.insert(referrals).values(data);
  }

  async getReferralsByUserId(userId: string): Promise<any[]> {
    return await db
      .select()
      .from(referrals)
      .where(eq(referrals.sponsorId, userId))
      .orderBy(desc(referrals.createdAt));
  }

  async createPayment(data: InsertPayment): Promise<any> {
    const [payment] = await db.insert(payments).values(data).returning();
    return payment;
  }

  async getPaymentsByUserId(userId: string): Promise<any[]> {
    return await db
      .select()
      .from(payments)
      .where(eq(payments.userId, userId))
      .orderBy(payments.createdAt); // Ascending order: 1-referral, 2-binary, 3-7 matrix, 8-system_fee
  }

  async getPendingConfirmations(userId: string): Promise<any[]> {
    return await db
      .select()
      .from(payments)
      .where(
        and(
          eq(payments.receiverId, userId),
          eq(payments.status, 'verifying')
        )
      )
      .orderBy(desc(payments.createdAt));
  }

  async getAllPayments(): Promise<any[]> {
    return await db.select().from(payments).orderBy(desc(payments.createdAt));
  }

  async updatePayment(id: string, data: Partial<any>): Promise<void> {
    await db.update(payments).set({ ...data, updatedAt: new Date() }).where(eq(payments.id, id));
  }

  async getBinaryTreeByUserId(userId: string): Promise<any> {
    const [tree] = await db.select().from(binaryTree).where(eq(binaryTree.userId, userId));
    return tree;
  }

  async createBinaryTree(data: any): Promise<void> {
    await db.insert(binaryTree).values(data);
  }

  async updateBinaryTree(userId: string, data: any): Promise<void> {
    await db.update(binaryTree).set(data).where(eq(binaryTree.userId, userId));
  }

  async createBinaryMatch(data: any): Promise<void> {
    await db.insert(binaryMatches).values(data);
  }

  async getBinaryMatchesByUserId(userId: string): Promise<any[]> {
    return await db
      .select()
      .from(binaryMatches)
      .where(eq(binaryMatches.userId, userId))
      .orderBy(desc(binaryMatches.createdAt));
  }

  async getMatrixPlacementsByUserId(userId: string): Promise<any[]> {
    return await db
      .select()
      .from(matrixPlacements)
      .where(eq(matrixPlacements.userId, userId))
      .orderBy(matrixPlacements.level);
  }

  async createMatrixPlacement(data: any): Promise<void> {
    await db.insert(matrixPlacements).values(data);
  }

  async getMatrixQueue(): Promise<any[]> {
    return await db
      .select()
      .from(matrixQueue)
      .orderBy(matrixQueue.queuePosition);
  }

  // Binary Queue (FIFO) implementations
  async getBinaryQueue(): Promise<any[]> {
    return await db
      .select()
      .from(binaryQueue)
      .where(eq(binaryQueue.hasReceivedPayment, false))
      .orderBy(binaryQueue.queuePosition);
  }

  async addToBinaryQueue(userId: string): Promise<void> {
    // Get current max position
    const queue = await db.select().from(binaryQueue).orderBy(desc(binaryQueue.queuePosition)).limit(1);
    const nextPosition = queue.length > 0 ? (queue[0].queuePosition || 0) + 1 : 1;
    
    // Add user to queue
    await db.insert(binaryQueue).values({
      userId,
      queuePosition: nextPosition,
      hasReceivedPayment: false,
    });
  }

  async removeFromBinaryQueue(userId: string): Promise<void> {
    // Mark as received payment instead of deleting (for tracking)
    await db
      .update(binaryQueue)
      .set({ hasReceivedPayment: true })
      .where(eq(binaryQueue.userId, userId));
  }

  async getNextInBinaryQueue(): Promise<any | undefined> {
    const queue = await this.getBinaryQueue();
    return queue.length > 0 ? queue[0] : undefined;
  }

  async createTransaction(data: InsertTransaction): Promise<void> {
    await db.insert(transactions).values(data);
  }

  async getTransactionsByUserId(userId: string): Promise<any[]> {
    return await db
      .select()
      .from(transactions)
      .where(eq(transactions.userId, userId))
      .orderBy(desc(transactions.createdAt));
  }

  async createNotification(data: InsertNotification): Promise<void> {
    await db.insert(notifications).values(data);
  }

  async getNotificationsByUserId(userId: string): Promise<any[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));
  }

  async createDispute(data: InsertDispute): Promise<void> {
    await db.insert(disputes).values(data);
  }

  async getDisputes(): Promise<any[]> {
    return await db
      .select()
      .from(disputes)
      .where(eq(disputes.status, 'pending'))
      .orderBy(desc(disputes.createdAt));
  }

  async resolveDispute(id: string, resolution: string): Promise<void> {
    await db
      .update(disputes)
      .set({ status: `resolved_for_${resolution}`, resolvedAt: new Date() })
      .where(eq(disputes.id, id));
  }

  async getSystemConfig(): Promise<SystemConfig | undefined> {
    const [config] = await db.select().from(systemConfig).limit(1);
    return config;
  }

  async updateSystemConfig(data: Partial<SystemConfig>): Promise<void> {
    await db
      .update(systemConfig)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(systemConfig.id, 'system'));
  }

  async createAdminNote(data: InsertAdminNote): Promise<void> {
    await db.insert(adminNotes).values(data);
  }

  async getAdminNotesByUserId(userId: string): Promise<any[]> {
    return await db
      .select()
      .from(adminNotes)
      .where(eq(adminNotes.userId, userId))
      .orderBy(desc(adminNotes.createdAt));
  }

  async getUserStats(userId: string): Promise<any> {
    const userTransactions = await this.getTransactionsByUserId(userId);
    
    const totalIncome = userTransactions.reduce((sum, t) => sum + parseFloat(t.amount.toString()), 0);
    const sponsorIncome = userTransactions
      .filter(t => t.transactionType === 'referral_income')
      .reduce((sum, t) => sum + parseFloat(t.amount.toString()), 0);
    const binaryIncome = userTransactions
      .filter(t => t.transactionType === 'binary_income')
      .reduce((sum, t) => sum + parseFloat(t.amount.toString()), 0);
    const matrixIncome = userTransactions
      .filter(t => t.transactionType === 'matrix_income')
      .reduce((sum, t) => sum + parseFloat(t.amount.toString()), 0);

    return {
      totalIncome,
      sponsorIncome,
      binaryIncome,
      matrixIncome,
    };
  }

  async createAdminAccount(data: any): Promise<any> {
    const [account] = await db.insert(adminAccounts).values(data).returning();
    return account;
  }

  async getAdminAccount(id: string): Promise<any | undefined> {
    const [account] = await db.select().from(adminAccounts).where(eq(adminAccounts.id, id));
    return account;
  }

  async getAdminAccounts(): Promise<any[]> {
    return await db.select().from(adminAccounts).orderBy(desc(adminAccounts.createdAt));
  }

  async getActiveAdminAccounts(): Promise<any[]> {
    return await db.select().from(adminAccounts).where(eq(adminAccounts.isActive, true));
  }

  async getRandomAdminAccount(): Promise<any | undefined> {
    const activeAccounts = await this.getActiveAdminAccounts();
    if (activeAccounts.length === 0) return undefined;
    
    // Pick random account for security/rotation
    const randomIndex = Math.floor(Math.random() * activeAccounts.length);
    return activeAccounts[randomIndex];
  }

  async updateAdminAccount(id: string, data: any): Promise<void> {
    await db.update(adminAccounts).set({ ...data, updatedAt: new Date() }).where(eq(adminAccounts.id, id));
  }

  async deleteAdminAccount(id: string): Promise<void> {
    await db.delete(adminAccounts).where(eq(adminAccounts.id, id));
  }

  async incrementAdminAccountUsage(id: string): Promise<void> {
    await db.update(adminAccounts).set({ usageCount: sql`${adminAccounts.usageCount} + 1` }).where(eq(adminAccounts.id, id));
  }
}

export const storage = new DatabaseStorage();
