import { sql } from 'drizzle-orm';
import { relations } from 'drizzle-orm';
import {
  pgTable,
  varchar,
  text,
  integer,
  boolean,
  timestamp,
  decimal,
  pgEnum,
  index,
  jsonb,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const positionEnum = pgEnum('position', ['left', 'right']);
export const paymentTypeEnum = pgEnum('payment_type', ['referral', 'binary', 'matrix_level_1', 'matrix_level_2', 'matrix_level_3', 'matrix_level_4', 'matrix_level_5', 'system_fee']);
export const paymentStatusEnum = pgEnum('payment_status', ['unpaid', 'pending', 'verifying', 'pending_confirmation', 'confirmed', 'expired', 'disputed']);
export const paymentMethodEnum = pgEnum('payment_method', ['qr', 'bank_transfer', 'upi', 'usdt']);
export const transactionTypeEnum = pgEnum('transaction_type', ['referral_income', 'binary_income', 'matrix_income', 'admin_income']);
export const accountStatusEnum = pgEnum('account_status', ['pending_activation', 'active', 'suspended']);

// Session storage table (MANDATORY for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (MANDATORY for Replit Auth)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  avatarUrl: varchar("avatar_url"), // Profile avatar
  phone: varchar("phone"),
  password: varchar("password"), // User password (hashed)
  isAdmin: boolean("is_admin").default(false).notNull(),
  accountStatus: accountStatusEnum("account_status").default('pending_activation').notNull(),
  sponsorId: varchar("sponsor_id"),
  position: positionEnum("position"), // left or right under sponsor
  // Payment receiving details
  bankAccountName: varchar("bank_account_name"),
  bankAccount: text("bank_account"),
  bankIfsc: varchar("bank_ifsc"),
  upiId: varchar("upi_id"),
  upiQrCode: varchar("upi_qr_code"),
  usdtAddress: varchar("usdt_address"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Referrals tracking
export const referrals = pgTable("referrals", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  sponsorId: varchar("sponsor_id").notNull().references(() => users.id),
  referredId: varchar("referred_id").notNull().references(() => users.id),
  position: positionEnum("position").notNull(), // left or right
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Payments for activation
export const payments = pgTable("payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  paymentType: paymentTypeEnum("payment_type").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  receiverId: varchar("receiver_id").references(() => users.id), // who receives this payment (user receiver)
  adminAccountId: varchar("admin_account_id"), // admin account ID when payment assigned to admin
  status: paymentStatusEnum("status").default('unpaid').notNull(),
  paymentMethod: paymentMethodEnum("payment_method"),
  transactionId: varchar("transaction_id"),
  transactionHash: varchar("transaction_hash"), // USDT BEP-20 transaction hash for auto-verification
  proofUrl: varchar("proof_url"), // stored in object storage
  cryptoAmount: varchar("crypto_amount"), // for USDT micro-amount matching (unique amounts)
  needsAdminConfirmation: boolean("needs_admin_confirmation").default(false), // true when binary queue empty or system fee
  expiresAt: timestamp("expires_at"),
  confirmedAt: timestamp("confirmed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Binary tree structure
export const binaryTree = pgTable("binary_tree", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  leftChildId: varchar("left_child_id").references(() => users.id),
  rightChildId: varchar("right_child_id").references(() => users.id),
  leftCount: integer("left_count").default(0).notNull(),
  rightCount: integer("right_count").default(0).notNull(),
  isQualified: boolean("is_qualified").default(false).notNull(), // has 1 left and 1 right paid sponsor
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Binary matching history
export const binaryMatches = pgTable("binary_matches", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  leftUserId: varchar("left_user_id").notNull().references(() => users.id),
  rightUserId: varchar("right_user_id").notNull().references(() => users.id),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Matrix placements (5 levels, 2-4-8-16-32 pattern)
export const matrixPlacements = pgTable("matrix_placements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  level: integer("level").notNull(), // 1-5
  position: integer("position").notNull(), // position in that level
  uplineId: varchar("upline_id").references(() => users.id), // immediate upline
  isFilled: boolean("is_filled").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Matrix queue (FIFO for spillover)
export const matrixQueue = pgTable("matrix_queue", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  queuePosition: integer("queue_position").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Binary queue (FIFO for binary payment distribution)
export const binaryQueue = pgTable("binary_queue", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().unique().references(() => users.id),
  queuePosition: integer("queue_position").notNull(),
  hasReceivedPayment: boolean("has_received_payment").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Transactions (all income records)
export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  transactionType: transactionTypeEnum("transaction_type").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  fromUserId: varchar("from_user_id").references(() => users.id), // who triggered this income
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Notifications
export const notifications = pgTable("notifications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  title: varchar("title").notNull(),
  message: text("message").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Disputes
export const disputes = pgTable("disputes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  paymentId: varchar("payment_id").notNull().references(() => payments.id),
  senderId: varchar("sender_id").notNull().references(() => users.id),
  receiverId: varchar("receiver_id").notNull().references(() => users.id),
  reason: text("reason"),
  status: varchar("status").default('pending').notNull(), // pending, resolved_for_sender, resolved_for_receiver
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// System configuration
export const systemConfig = pgTable("system_config", {
  id: varchar("id").primaryKey().default('system'),
  referralIncome: decimal("referral_income", { precision: 10, scale: 2 }).default('1000').notNull(),
  binaryIncome: decimal("binary_income", { precision: 10, scale: 2 }).default('1000').notNull(),
  matrixIncomePerLevel: decimal("matrix_income_per_level", { precision: 10, scale: 2 }).default('500').notNull(),
  adminFeePerUser: decimal("admin_fee_per_user", { precision: 10, scale: 2 }).default('500').notNull(),
  paymentSubmissionTimerMinutes: integer("payment_submission_timer_minutes").default(1440).notNull(), // 24 hours to submit payment proof
  paymentConfirmationTimerMinutes: integer("payment_confirmation_timer_minutes").default(720).notNull(), // 12 hours to confirm payment
  paymentTimerMinutes: integer("payment_timer_minutes").default(1440).notNull(), // 24 hours (legacy - for backward compatibility)
  totalActivationFee: decimal("total_activation_fee", { precision: 10, scale: 2 }).default('5000').notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Admin notes on users
export const adminNotes = pgTable("admin_notes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  note: text("note").notNull(),
  createdBy: varchar("created_by").notNull().references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Admin accounts for system fee collection
export const adminAccounts = pgTable("admin_accounts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: varchar("name").notNull(), // Account name/label
  bankAccountName: varchar("bank_account_name"),
  bankAccount: text("bank_account"),
  bankIfsc: varchar("bank_ifsc"),
  upiId: varchar("upi_id"),
  upiQrCode: varchar("upi_qr_code"),
  usdtAddress: varchar("usdt_address"),
  isActive: boolean("is_active").default(true).notNull(),
  usageCount: integer("usage_count").default(0).notNull(), // track how many times used
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ one, many }) => ({
  sponsor: one(users, {
    fields: [users.sponsorId],
    references: [users.id],
    relationName: 'sponsor'
  }),
  referrals: many(referrals),
  payments: many(payments),
  binaryTree: one(binaryTree),
  transactions: many(transactions),
  notifications: many(notifications),
}));

export const referralsRelations = relations(referrals, ({ one }) => ({
  sponsor: one(users, {
    fields: [referrals.sponsorId],
    references: [users.id],
  }),
  referred: one(users, {
    fields: [referrals.referredId],
    references: [users.id],
  }),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  user: one(users, {
    fields: [payments.userId],
    references: [users.id],
  }),
  receiver: one(users, {
    fields: [payments.receiverId],
    references: [users.id],
  }),
}));

export const binaryTreeRelations = relations(binaryTree, ({ one }) => ({
  user: one(users, {
    fields: [binaryTree.userId],
    references: [users.id],
  }),
  leftChild: one(users, {
    fields: [binaryTree.leftChildId],
    references: [users.id],
  }),
  rightChild: one(users, {
    fields: [binaryTree.rightChildId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertReferralSchema = createInsertSchema(referrals).omit({
  id: true,
  createdAt: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({
  id: true,
  createdAt: true,
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  createdAt: true,
});

export const insertDisputeSchema = createInsertSchema(disputes).omit({
  id: true,
  createdAt: true,
});

export const insertAdminNoteSchema = createInsertSchema(adminNotes).omit({
  id: true,
  createdAt: true,
});

export const insertAdminAccountSchema = createInsertSchema(adminAccounts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  usageCount: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = z.infer<typeof insertReferralSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type BinaryTree = typeof binaryTree.$inferSelect;
export type BinaryMatch = typeof binaryMatches.$inferSelect;
export type BinaryQueue = typeof binaryQueue.$inferSelect;
export type MatrixPlacement = typeof matrixPlacements.$inferSelect;
export type MatrixQueue = typeof matrixQueue.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Dispute = typeof disputes.$inferSelect;
export type InsertDispute = z.infer<typeof insertDisputeSchema>;
export type SystemConfig = typeof systemConfig.$inferSelect;
export type AdminNote = typeof adminNotes.$inferSelect;
export type InsertAdminNote = z.infer<typeof insertAdminNoteSchema>;
export type AdminAccount = typeof adminAccounts.$inferSelect;
export type InsertAdminAccount = z.infer<typeof insertAdminAccountSchema>;

// Signup schema for referral links
export const signupSchema = z.object({
  email: z.string().email().optional(),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  phone: z.string().min(10),
  sponsorId: z.string().optional(),
  position: z.enum(['left', 'right']).optional(),
});

export type SignupData = z.infer<typeof signupSchema>;
