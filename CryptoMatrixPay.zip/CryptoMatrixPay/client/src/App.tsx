import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { ThemeToggle } from "@/components/theme-toggle";
import { useAuth } from "@/hooks/useAuth";
import { useWebSocket } from "@/hooks/useWebSocket";
import { Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";

import Landing from "@/pages/landing";
import Dashboard from "@/pages/dashboard";
import Join from "@/pages/join";
import Confirmations from "@/pages/confirmations";
import Binary from "@/pages/binary";
import Matrix from "@/pages/matrix";
import Sponsor from "@/pages/sponsor";
import Transactions from "@/pages/transactions";
import Analytics from "@/pages/analytics";
import Genealogy from "@/pages/genealogy";
import Profile from "@/pages/profile";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminDisputes from "@/pages/admin/disputes";
import AdminUsers from "@/pages/admin/users";
import AdminPaymentAccounts from "@/pages/admin/payment-accounts";
import AdminPaymentConfirmations from "@/pages/admin/confirmations";
import AdminSystemFees from "@/pages/admin/system-fees";
import SystemConfigPage from "@/pages/admin/system-config";
import AdminLogin from "@/pages/admin/login";
import AdminSetup from "@/pages/admin/setup";
import NotFound from "@/pages/not-found";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();
  const [location] = useLocation();

  if (isLoading || !isAuthenticated) {
    return (
      <Switch>
        <Route path="/" component={Landing} />
        <Route path="/admin/login" component={AdminLogin} />
        <Route path="/admin/setup" component={AdminSetup} />
        <Route path="/admin/dashboard" component={AdminDashboard} />
        <Route path="/admin/disputes" component={AdminDisputes} />
        <Route path="/admin/users" component={AdminUsers} />
        <Route path="/admin/payment-accounts" component={AdminPaymentAccounts} />
        <Route path="/admin/confirmations" component={AdminPaymentConfirmations} />
        <Route path="/admin/system-fees" component={AdminSystemFees} />
        <Route path="/admin/config" component={SystemConfigPage} />
        <Route component={NotFound} />
      </Switch>
    );
  }

  return (
    <Switch>
      <Route path="/" component={() => <Redirect to="/dashboard" />} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/join" component={Join} />
      <Route path="/confirmations" component={Confirmations} />
      <Route path="/binary" component={Binary} />
      <Route path="/matrix" component={Matrix} />
      <Route path="/sponsor" component={Sponsor} />
      <Route path="/transactions" component={Transactions} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/genealogy" component={Genealogy} />
      <Route path="/profile" component={Profile} />
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin/setup" component={AdminSetup} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/admin/disputes" component={AdminDisputes} />
      <Route path="/admin/users" component={AdminUsers} />
      <Route path="/admin/payment-accounts" component={AdminPaymentAccounts} />
      <Route path="/admin/confirmations" component={AdminPaymentConfirmations} />
      <Route path="/admin/system-fees" component={AdminSystemFees} />
      <Route path="/admin/config" component={SystemConfigPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppContent() {
  const { isAuthenticated, isLoading, user } = useAuth();
  const [location] = useLocation();
  
  // Connect to WebSocket for real-time notifications
  useWebSocket(user?.id || null);

  if (isLoading || !isAuthenticated) {
    return <Router />;
  }

  const pageTitles: Record<string, string> = {
    '/dashboard': 'Dashboard',
    '/join': 'Account Activation',
    '/confirmations': 'Payment Confirmations',
    '/binary': 'Binary Income',
    '/matrix': 'Matrix Income',
    '/sponsor': 'Sponsor Income',
    '/transactions': 'Transaction History',
    '/analytics': 'Analytics Dashboard',
    '/genealogy': 'Network Genealogy',
    '/profile': 'Profile Settings',
    '/admin/dashboard': 'Admin Dashboard',
    '/admin/disputes': 'Payment Disputes',
    '/admin/users': 'User Management',
    '/admin/payment-accounts': 'Admin Payment Accounts',
    '/admin/config': 'System Configuration',
  };

  const style = {
    "--sidebar-width": "20rem",
    "--sidebar-width-icon": "4rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full">
        <AppSidebar />
        <div className="flex flex-col flex-1">
          <header className="sticky top-0 z-40 flex items-center justify-between h-16 px-6 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
            <div className="flex items-center gap-4">
              <SidebarTrigger data-testid="button-sidebar-toggle" />
              <h1 className="text-xl font-semibold">{pageTitles[location] || 'Payback247'}</h1>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" className="relative" data-testid="button-notifications">
                <Bell className="h-5 w-5" />
                <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center text-xs">
                  3
                </Badge>
              </Button>
              <ThemeToggle />
            </div>
          </header>
          <main className="flex-1 overflow-y-auto p-6 bg-background">
            <div className="max-w-7xl mx-auto">
              <Router />
            </div>
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AppContent />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}
