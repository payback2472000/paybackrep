import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
} from "@/components/ui/sidebar";
import {
  LayoutDashboard,
  CreditCard,
  CheckCircle2,
  Network,
  TrendingUp,
  Users,
  Receipt,
  BarChart3,
  GitBranch,
  User,
  AlertTriangle,
  UsersRound,
  Settings,
  LogOut,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

export function AppSidebar() {
  const [location, setLocation] = useLocation();
  const { user } = useAuth();

  const mainMenuItems = [
    { title: "Dashboard", url: "/dashboard", icon: LayoutDashboard, testId: "nav-dashboard" },
    { title: "Join", url: "/join", icon: CreditCard, testId: "nav-join" },
    { title: "Confirmations", url: "/confirmations", icon: CheckCircle2, badge: 0, testId: "nav-confirmations" },
    { title: "Binary", url: "/binary", icon: Network, testId: "nav-binary" },
    { title: "Matrix", url: "/matrix", icon: TrendingUp, testId: "nav-matrix" },
    { title: "Sponsor", url: "/sponsor", icon: Users, testId: "nav-sponsor" },
    { title: "Transactions", url: "/transactions", icon: Receipt, testId: "nav-transactions" },
    { title: "Analytics", url: "/analytics", icon: BarChart3, testId: "nav-analytics" },
    { title: "Genealogy", url: "/genealogy", icon: GitBranch, testId: "nav-genealogy" },
    { title: "Profile", url: "/profile", icon: User, testId: "nav-profile" },
  ];

  const adminMenuItems = [
    { title: "Dashboard", url: "/admin/dashboard", icon: LayoutDashboard, testId: "nav-admin-dashboard" },
    { title: "Disputes", url: "/admin/disputes", icon: AlertTriangle, badge: 0, testId: "nav-disputes" },
    { title: "Users", url: "/admin/users", icon: UsersRound, testId: "nav-users" },
    { title: "Payment Accounts", url: "/admin/payment-accounts", icon: CreditCard, testId: "nav-payment-accounts" },
    { title: "System Config", url: "/admin/config", icon: Settings, testId: "nav-config" },
  ];

  return (
    <Sidebar>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-lg font-display font-bold">
            <div className="flex items-center gap-2">
              <img 
                src="/payback247-logo.png" 
                alt="Payback247 Logo" 
                className="h-8 w-8"
                data-testid="sidebar-logo"
              />
              <span>Payback247</span>
            </div>
          </SidebarGroupLabel>
          <SidebarGroupContent className="mt-4">
            <SidebarMenu>
              {mainMenuItems.map((item) => (
                <SidebarMenuItem key={item.url}>
                  <SidebarMenuButton
                    asChild
                    isActive={location === item.url}
                    data-testid={item.testId}
                  >
                    <a href={item.url} onClick={(e) => {
                      e.preventDefault();
                      setLocation(item.url);
                    }}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                      {item.badge !== undefined && item.badge > 0 && (
                        <Badge variant="destructive" className="ml-auto h-5 w-5 p-0 flex items-center justify-center text-xs">
                          {item.badge}
                        </Badge>
                      )}
                    </a>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {user?.isAdmin && (
          <SidebarGroup>
            <SidebarGroupLabel>Admin</SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {adminMenuItems.map((item) => (
                  <SidebarMenuItem key={item.url}>
                    <SidebarMenuButton
                      asChild
                      isActive={location === item.url}
                      data-testid={item.testId}
                    >
                      <a href={item.url} onClick={(e) => {
                        e.preventDefault();
                        setLocation(item.url);
                      }}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                        {item.badge !== undefined && item.badge > 0 && (
                          <Badge variant="destructive" className="ml-auto h-5 w-5 p-0 flex items-center justify-center text-xs">
                            {item.badge}
                          </Badge>
                        )}
                      </a>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild data-testid="button-logout">
              <a href="/api/logout">
                <LogOut className="h-4 w-4" />
                <span>Logout</span>
              </a>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
