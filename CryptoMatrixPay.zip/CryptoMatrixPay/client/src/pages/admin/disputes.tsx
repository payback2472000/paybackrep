import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { AlertTriangle, Eye, CheckCircle2, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Dispute } from "@shared/schema";
import { AdminLayout } from "@/components/admin-layout";

export default function AdminDisputes() {
  const { toast } = useToast();
  const [selectedProof, setSelectedProof] = useState<string | null>(null);

  const { data: disputes = [] } = useQuery<Dispute[]>({
    queryKey: ["/api/admin/disputes"],
  });

  const resolveMutation = useMutation({
    mutationFn: async ({ disputeId, resolution }: { disputeId: string; resolution: 'sender' | 'receiver' }) => {
      return await apiRequest("POST", `/api/admin/disputes/${disputeId}/resolve`, { resolution });
    },
    onSuccess: () => {
      toast({
        title: "Dispute Resolved",
        description: "The dispute has been resolved successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/disputes"] });
    },
  });

  return (
    <AdminLayout>
      <div className="space-y-6">
      <div>
        <h2 className="text-headline-md font-display mb-2">Payment Disputes</h2>
        <p className="text-muted-foreground">
          Resolve payment disputes between members ({disputes.length} pending)
        </p>
      </div>

      {disputes.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <CheckCircle2 className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No Pending Disputes</h3>
            <p className="text-sm text-muted-foreground">
              All payment disputes have been resolved
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {disputes.map((dispute) => (
            <Card key={dispute.id} data-testid={`dispute-card-${dispute.id}`}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5 text-warning" />
                    Dispute #{dispute.id.slice(0, 8)}
                  </CardTitle>
                  <Badge variant="outline" className="text-warning border-warning">
                    Pending Review
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-1">Sender</p>
                    <p className="font-mono text-sm">{dispute.senderId.slice(0, 12)}...</p>
                  </div>
                  <div className="p-4 bg-muted/50 rounded-lg">
                    <p className="text-sm text-muted-foreground mb-1">Receiver</p>
                    <p className="font-mono text-sm">{dispute.receiverId.slice(0, 12)}...</p>
                  </div>
                </div>

                {dispute.reason && (
                  <div className="p-3 bg-warning/10 rounded-lg border border-warning/20">
                    <p className="text-sm font-medium mb-1">Reason:</p>
                    <p className="text-sm text-muted-foreground">{dispute.reason}</p>
                  </div>
                )}

                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => setSelectedProof(`/api/proof/${dispute.paymentId}`)}
                    data-testid="button-view-proof-admin"
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    View Proof
                  </Button>
                  <Button
                    variant="default"
                    className="flex-1"
                    onClick={() => resolveMutation.mutate({ disputeId: dispute.id, resolution: 'sender' })}
                    disabled={resolveMutation.isPending}
                    data-testid="button-resolve-sender"
                  >
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Resolve for Sender
                  </Button>
                  <Button
                    variant="destructive"
                    className="flex-1"
                    onClick={() => resolveMutation.mutate({ disputeId: dispute.id, resolution: 'receiver' })}
                    disabled={resolveMutation.isPending}
                    data-testid="button-resolve-receiver"
                  >
                    <XCircle className="h-4 w-4 mr-2" />
                    Resolve for Receiver
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!selectedProof} onOpenChange={() => setSelectedProof(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Payment Proof</DialogTitle>
          </DialogHeader>
          {selectedProof && (
            <img
              src={selectedProof}
              alt="Payment proof"
              className="w-full rounded-lg"
            />
          )}
        </DialogContent>
      </Dialog>
      </div>
    </AdminLayout>
  );
}
