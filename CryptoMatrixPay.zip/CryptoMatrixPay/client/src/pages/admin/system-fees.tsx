import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { CheckCircle2, Eye, DollarSign } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { AdminLayout } from "@/components/admin-layout";

interface SystemFeeConfirmation {
  id: string;
  userId: string;
  amount: string;
  paymentType: string;
  status: string;
  receiverId: string;
  proofUrl: string;
  paymentMethod: string;
  transactionHash: string;
  createdAt: string;
  userFirstName: string;
  userLastName: string;
  userEmail: string;
}

export default function AdminSystemFees() {
  const { toast } = useToast();
  const [selectedProof, setSelectedProof] = useState<string | null>(null);

  const { data: confirmations = [] } = useQuery<SystemFeeConfirmation[]>({
    queryKey: ["/api/admin/system-fee-confirmations"],
  });

  const confirmMutation = useMutation({
    mutationFn: async (paymentId: string) => {
      return await apiRequest("POST", `/api/admin/system-fee-confirmations/${paymentId}/confirm`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/system-fee-confirmations"] });
      toast({
        title: "System Fee Confirmed",
        description: "The system fee has been confirmed successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to confirm system fee",
        variant: "destructive",
      });
    },
  });

  const getPaymentMethodLabel = (method: string) => {
    switch (method) {
      case 'bank': return 'Bank Transfer';
      case 'upi': return 'UPI';
      case 'qr': return 'QR Code';
      case 'usdt': return 'USDT BEP-20';
      default: return method;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending_confirmation':
        return <Badge variant="secondary">Pending Confirmation</Badge>;
      case 'confirmed':
        return <Badge variant="default">Confirmed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h2 className="text-headline-md font-display mb-2">System Fee Confirmations</h2>
          <p className="text-muted-foreground">
            Confirm system fee payments (₹500 each) ({confirmations.length} pending)
          </p>
        </div>

        {confirmations.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <CheckCircle2 className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-semibold mb-2">No Pending Confirmations</h3>
              <p className="text-sm text-muted-foreground">
                All system fees have been confirmed
              </p>
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle>Pending System Fee Confirmations</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Proof</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {confirmations.map((payment) => (
                    <TableRow key={payment.id} data-testid={`row-system-fee-${payment.id}`}>
                      <TableCell>
                        <div>
                          <div className="font-medium">
                            {payment.userFirstName} {payment.userLastName}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {payment.userEmail}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="font-semibold">
                        ₹{payment.amount}
                      </TableCell>
                      <TableCell>
                        {getPaymentMethodLabel(payment.paymentMethod)}
                      </TableCell>
                      <TableCell>{getStatusBadge(payment.status)}</TableCell>
                      <TableCell>
                        {payment.proofUrl ? (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setSelectedProof(payment.proofUrl)}
                            data-testid={`button-view-proof-${payment.id}`}
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                        ) : (
                          <span className="text-sm text-muted-foreground">No proof</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            onClick={() => confirmMutation.mutate(payment.id)}
                            disabled={confirmMutation.isPending}
                            data-testid={`button-confirm-system-fee-${payment.id}`}
                          >
                            <CheckCircle2 className="h-4 w-4 mr-1" />
                            Confirm
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {/* Proof Preview Dialog */}
        <Dialog open={!!selectedProof} onOpenChange={() => setSelectedProof(null)}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Payment Proof</DialogTitle>
            </DialogHeader>
            {selectedProof && (
              <img
                src={selectedProof}
                alt="Payment proof"
                className="w-full rounded-lg"
              />
            )}
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
