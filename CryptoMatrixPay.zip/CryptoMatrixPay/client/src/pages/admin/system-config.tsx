import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Settings, AlertTriangle, Save, Edit } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { SystemConfig } from "@shared/schema";
import { AdminNav } from "@/components/admin-nav";

export default function SystemConfigPage() {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [config, setConfig] = useState<Partial<SystemConfig>>({});

  const { data: systemConfig } = useQuery<SystemConfig>({
    queryKey: ["/api/admin/config"],
  });

  useEffect(() => {
    if (systemConfig) {
      setConfig(systemConfig);
    }
  }, [systemConfig]);

  const updateConfigMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("PUT", "/api/admin/config", config);
    },
    onSuccess: () => {
      toast({
        title: "Configuration Updated",
        description: "System configuration has been saved",
      });
      setIsEditing(false);
      queryClient.invalidateQueries({ queryKey: ["/api/admin/config"] });
    },
  });

  const resetAppMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/admin/reset", {});
    },
    onSuccess: () => {
      toast({
        title: "Application Reset",
        description: "All data has been cleared",
        variant: "destructive",
      });
      window.location.reload();
    },
  });

  return (
    <AdminNav>
      <div className="space-y-6">
      <div>
        <h2 className="text-headline-md font-display mb-2">System Configuration</h2>
        <p className="text-muted-foreground">Manage income amounts, timers, and system settings</p>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Income Configuration
            </CardTitle>
            <CardDescription>Set income amounts for all earning types</CardDescription>
          </div>
          {!isEditing ? (
            <Button
              variant="outline"
              onClick={() => setIsEditing(true)}
              data-testid="button-edit-config"
            >
              <Edit className="h-4 w-4 mr-2" />
              Edit
            </Button>
          ) : (
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  setConfig(systemConfig || {});
                  setIsEditing(false);
                }}
                data-testid="button-cancel-edit"
              >
                Cancel
              </Button>
              <Button
                onClick={() => updateConfigMutation.mutate()}
                disabled={updateConfigMutation.isPending}
                data-testid="button-save-config"
              >
                <Save className="h-4 w-4 mr-2" />
                Save Changes
              </Button>
            </div>
          )}
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="referral-income">Referral Income (₹)</Label>
              <Input
                id="referral-income"
                type="number"
                value={config.referralIncome || ''}
                onChange={(e) => setConfig({ ...config, referralIncome: e.target.value as any })}
                disabled={!isEditing}
                data-testid="input-referral-income"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="binary-income">Binary Income (₹)</Label>
              <Input
                id="binary-income"
                type="number"
                value={config.binaryIncome || ''}
                onChange={(e) => setConfig({ ...config, binaryIncome: e.target.value as any })}
                disabled={!isEditing}
                data-testid="input-binary-income"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="matrix-income">Matrix Income Per Level (₹)</Label>
              <Input
                id="matrix-income"
                type="number"
                value={config.matrixIncomePerLevel || ''}
                onChange={(e) => setConfig({ ...config, matrixIncomePerLevel: e.target.value as any })}
                disabled={!isEditing}
                data-testid="input-matrix-income"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="admin-fee">Admin Fee Per User (₹)</Label>
              <Input
                id="admin-fee"
                type="number"
                value={config.adminFeePerUser || ''}
                onChange={(e) => setConfig({ ...config, adminFeePerUser: e.target.value as any })}
                disabled={!isEditing}
                data-testid="input-admin-fee"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="activation-fee">Total Activation Fee (₹)</Label>
              <Input
                id="activation-fee"
                type="number"
                value={config.totalActivationFee || ''}
                onChange={(e) => setConfig({ ...config, totalActivationFee: e.target.value as any })}
                disabled={!isEditing}
                data-testid="input-activation-fee"
              />
            </div>
          </div>

          <div className="border-t pt-6 mt-6">
            <h3 className="text-lg font-semibold mb-4">Payment Timer Settings</h3>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="submission-timer">Payment Submission Timer (minutes)</Label>
                <Input
                  id="submission-timer"
                  type="number"
                  value={config.paymentSubmissionTimerMinutes || ''}
                  onChange={(e) => setConfig({ ...config, paymentSubmissionTimerMinutes: parseInt(e.target.value) })}
                  disabled={!isEditing}
                  data-testid="input-submission-timer"
                />
                <p className="text-sm text-muted-foreground">
                  Time limit for users to submit payment proof (default: 1440 minutes / 24 hours)
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirmation-timer">Payment Confirmation Timer (minutes)</Label>
                <Input
                  id="confirmation-timer"
                  type="number"
                  value={config.paymentConfirmationTimerMinutes || ''}
                  onChange={(e) => setConfig({ ...config, paymentConfirmationTimerMinutes: parseInt(e.target.value) })}
                  disabled={!isEditing}
                  data-testid="input-confirmation-timer"
                />
                <p className="text-sm text-muted-foreground">
                  Time limit for receivers to confirm/reject payments (default: 720 minutes / 12 hours)
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Danger Zone */}
      <Card className="border-destructive/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-destructive">
            <AlertTriangle className="h-5 w-5" />
            Danger Zone
          </CardTitle>
          <CardDescription>Irreversible actions that affect all data</CardDescription>
        </CardHeader>
        <CardContent>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" data-testid="button-reset-app">
                Reset Application Data
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete all users, payments, transactions, and system data.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => resetAppMutation.mutate()}
                  className="bg-destructive hover:bg-destructive/90"
                >
                  Reset Everything
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </CardContent>
      </Card>
      </div>
    </AdminNav>
  );
}
