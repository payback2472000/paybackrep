import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, DollarSign, CreditCard, AlertTriangle, TrendingUp, UserCheck } from "lucide-react";
import { AdminLayout } from "@/components/admin-layout";

export default function AdminDashboard() {
  const { data: analytics } = useQuery<{
    users: {
      total: number;
      active: number;
      pendingActivation: number;
    };
    payments: {
      total: number;
      confirmed: number;
      pending: number;
      disputed: number;
    };
    revenue: {
      total: number;
    };
  }>({
    queryKey: ["/api/admin/analytics"],
  });

  const statCards = [
    {
      title: "Total Users",
      value: analytics?.users.total || 0,
      icon: Users,
      color: "text-primary",
      bgColor: "bg-primary/10",
      testId: "stat-total-users",
    },
    {
      title: "Active Users",
      value: analytics?.users.active || 0,
      icon: UserCheck,
      color: "text-success",
      bgColor: "bg-success/10",
      testId: "stat-active-users",
    },
    {
      title: "Pending Activation",
      value: analytics?.users.pendingActivation || 0,
      icon: AlertTriangle,
      color: "text-warning",
      bgColor: "bg-warning/10",
      testId: "stat-pending-users",
    },
    {
      title: "Total Revenue",
      value: `₹${analytics?.revenue.total?.toLocaleString() || 0}`,
      icon: DollarSign,
      color: "text-success",
      bgColor: "bg-success/10",
      testId: "stat-revenue",
    },
    {
      title: "Total Payments",
      value: analytics?.payments.total || 0,
      icon: CreditCard,
      color: "text-info",
      bgColor: "bg-info/10",
      testId: "stat-total-payments",
    },
    {
      title: "Confirmed Payments",
      value: analytics?.payments.confirmed || 0,
      icon: TrendingUp,
      color: "text-success",
      bgColor: "bg-success/10",
      testId: "stat-confirmed-payments",
    },
    {
      title: "Pending Payments",
      value: analytics?.payments.pending || 0,
      icon: CreditCard,
      color: "text-warning",
      bgColor: "bg-warning/10",
      testId: "stat-pending-payments",
    },
    {
      title: "Disputed Payments",
      value: analytics?.payments.disputed || 0,
      icon: AlertTriangle,
      color: "text-destructive",
      bgColor: "bg-destructive/10",
      testId: "stat-disputed-payments",
    },
  ];

  return (
    <AdminLayout>
      <div className="space-y-8">
        <div>
          <h2 className="text-headline-md font-display mb-2">Admin Dashboard</h2>
          <p className="text-muted-foreground">
            Overview of system statistics and performance
          </p>
        </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statCards.map((stat) => (
          <Card key={stat.title} data-testid={stat.testId}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <div className={`p-2 rounded-lg ${stat.bgColor}`}>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-display font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Links */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card className="hover-elevate cursor-pointer" data-testid="card-quick-link-users">
          <a href="/admin/users" className="block">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                User Management
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                View and manage all users in the system
              </p>
            </CardContent>
          </a>
        </Card>

        <Card className="hover-elevate cursor-pointer" data-testid="card-quick-link-disputes">
          <a href="/admin/disputes" className="block">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                Payment Disputes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Review and resolve payment disputes
              </p>
            </CardContent>
          </a>
        </Card>

        <Card className="hover-elevate cursor-pointer" data-testid="card-quick-link-payment-accounts">
          <a href="/admin/payment-accounts" className="block">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Payment Accounts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Manage admin payment receiving accounts
              </p>
            </CardContent>
          </a>
        </Card>

        <Card className="hover-elevate cursor-pointer" data-testid="card-quick-link-config">
          <a href="/admin/config" className="block">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                System Configuration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Configure system settings and payment amounts
              </p>
            </CardContent>
          </a>
        </Card>
      </div>
    </div>
    </AdminLayout>
  );
}
