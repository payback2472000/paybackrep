import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { AdminLayout } from "@/components/admin-layout";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Switch } from "@/components/ui/switch";
import { Plus, Pencil, Trash2, CreditCard } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { AdminAccount } from "@shared/schema";

export default function AdminPaymentAccounts() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<AdminAccount | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    bankAccountName: "",
    bankAccount: "",
    bankIfsc: "",
    upiId: "",
    usdtAddress: "",
  });

  const { data: accounts } = useQuery<AdminAccount[]>({
    queryKey: ["/api/admin/payment-accounts"],
  });

  const createMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("POST", "/api/admin/payment-accounts", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/payment-accounts"] });
      setDialogOpen(false);
      resetForm();
      toast({
        title: "Success",
        description: "Payment account created successfully",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      return await apiRequest("PUT", `/api/admin/payment-accounts/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/payment-accounts"] });
      setDialogOpen(false);
      resetForm();
      toast({
        title: "Success",
        description: "Payment account updated successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update payment account",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/admin/payment-accounts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/payment-accounts"] });
      toast({
        title: "Success",
        description: "Payment account deleted successfully",
      });
    },
  });

  const toggleActiveMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: string; isActive: boolean }) => {
      return await apiRequest("PUT", `/api/admin/payment-accounts/${id}`, { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/payment-accounts"] });
      toast({
        title: "Success",
        description: "Account status updated successfully",
      });
    },
  });

  const resetForm = () => {
    setFormData({
      name: "",
      bankAccountName: "",
      bankAccount: "",
      bankIfsc: "",
      upiId: "",
      usdtAddress: "",
    });
    setEditingAccount(null);
  };

  const handleOpenDialog = (account?: AdminAccount) => {
    if (account) {
      setEditingAccount(account);
      setFormData({
        name: account.name,
        bankAccountName: account.bankAccountName || "",
        bankAccount: account.bankAccount || "",
        bankIfsc: account.bankIfsc || "",
        upiId: account.upiId || "",
        usdtAddress: account.usdtAddress || "",
      });
    } else {
      resetForm();
    }
    setDialogOpen(true);
  };

  const handleSubmit = () => {
    if (!formData.name) {
      toast({
        title: "Error",
        description: "Account name is required",
        variant: "destructive",
      });
      return;
    }

    if (editingAccount) {
      updateMutation.mutate({ id: editingAccount.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
        <div>
          <h2 className="text-headline-md font-display mb-2">Admin Payment Accounts</h2>
          <p className="text-muted-foreground">
            Manage payment receiving accounts for admin fees (₹500 per user)
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) {
            resetForm();
          }
        }}>
          <DialogTrigger asChild>
            <Button onClick={() => handleOpenDialog()} data-testid="button-add-account">
              <Plus className="h-4 w-4 mr-2" />
              Add Account
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingAccount ? "Edit Payment Account" : "Add Payment Account"}
              </DialogTitle>
              <DialogDescription>
                Add payment methods for receiving admin fees from users
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Account Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="e.g., Primary Admin Account"
                  data-testid="input-account-name"
                />
              </div>

              <div className="space-y-2">
                <h4 className="font-semibold">Bank Transfer Details</h4>
                <div>
                  <Label htmlFor="bankAccountName">Account Holder Name</Label>
                  <Input
                    id="bankAccountName"
                    value={formData.bankAccountName}
                    onChange={(e) =>
                      setFormData({ ...formData, bankAccountName: e.target.value })
                    }
                    placeholder="Full name as per bank"
                    data-testid="input-bank-account-name"
                  />
                </div>
                <div>
                  <Label htmlFor="bankAccount">Bank Account Number</Label>
                  <Input
                    id="bankAccount"
                    value={formData.bankAccount}
                    onChange={(e) =>
                      setFormData({ ...formData, bankAccount: e.target.value })
                    }
                    placeholder="Enter account number"
                    data-testid="input-bank-account"
                  />
                </div>
                <div>
                  <Label htmlFor="bankIfsc">IFSC Code</Label>
                  <Input
                    id="bankIfsc"
                    value={formData.bankIfsc}
                    onChange={(e) =>
                      setFormData({ ...formData, bankIfsc: e.target.value })
                    }
                    placeholder="Enter IFSC code"
                    data-testid="input-bank-ifsc"
                  />
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-2">UPI Details</h4>
                <Label htmlFor="upiId">UPI ID</Label>
                <Input
                  id="upiId"
                  value={formData.upiId}
                  onChange={(e) => setFormData({ ...formData, upiId: e.target.value })}
                  placeholder="yourname@upi"
                  data-testid="input-upi-id"
                />
              </div>

              <div>
                <h4 className="font-semibold mb-2">Cryptocurrency</h4>
                <Label htmlFor="usdtAddress">USDT (BEP-20) Address</Label>
                <Input
                  id="usdtAddress"
                  value={formData.usdtAddress}
                  onChange={(e) =>
                    setFormData({ ...formData, usdtAddress: e.target.value })
                  }
                  placeholder="0x..."
                  data-testid="input-usdt-address"
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setDialogOpen(false)}
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={createMutation.isPending || updateMutation.isPending}
                data-testid="button-submit"
              >
                {createMutation.isPending || updateMutation.isPending
                  ? "Saving..."
                  : editingAccount
                  ? "Update Account"
                  : "Create Account"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Payment Accounts</CardTitle>
        </CardHeader>
        <CardContent>
          {!accounts?.length ? (
            <div className="text-center py-12">
              <CreditCard className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-semibold mb-2">No Payment Accounts</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Add payment accounts to receive admin fees from users
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Bank Details</TableHead>
                  <TableHead>UPI ID</TableHead>
                  <TableHead>USDT Address</TableHead>
                  <TableHead>Usage</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {accounts.map((account) => (
                  <TableRow key={account.id} data-testid={`row-account-${account.id}`}>
                    <TableCell className="font-medium">{account.name}</TableCell>
                    <TableCell>
                      {account.bankAccount ? (
                        <div className="text-sm">
                          <div>{account.bankAccountName}</div>
                          <div className="text-muted-foreground">
                            {account.bankAccount} ({account.bankIfsc})
                          </div>
                        </div>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {account.upiId || (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell className="font-mono text-xs">
                      {account.usdtAddress ? (
                        `${account.usdtAddress.slice(0, 8)}...`
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell>{account.usageCount} times</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={account.isActive}
                          onCheckedChange={(checked) =>
                            toggleActiveMutation.mutate({
                              id: account.id,
                              isActive: checked,
                            })
                          }
                          data-testid={`switch-active-${account.id}`}
                        />
                        <Badge variant={account.isActive ? "default" : "secondary"}>
                          {account.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => handleOpenDialog(account)}
                          data-testid={`button-edit-${account.id}`}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() => deleteMutation.mutate(account.id)}
                          data-testid={`button-delete-${account.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
    </AdminLayout>
  );
}
