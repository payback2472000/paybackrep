import { useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Users, TrendingUp, Network, DollarSign, ArrowRight, CheckCircle2 } from "lucide-react";
import heroImage from "@assets/generated_images/Hero_image_business_collaboration_d773265d.png";

export default function Landing() {
  useEffect(() => {
    // Capture referral parameters from URL and store in session
    const params = new URLSearchParams(window.location.search);
    const ref = params.get('ref');
    const pos = params.get('pos');
    
    if (ref && pos) {
      // Send to backend to store in session
      fetch('/api/referral/store', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sponsorId: ref, position: pos }),
        credentials: 'include',
      }).catch(err => console.error('Failed to store referral info:', err));
    }
  }, []);

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img 
              src="/payback247-logo.png" 
              alt="Payback247 Logo" 
              className="h-10 w-10"
              data-testid="logo-image"
            />
            <h1 className="text-2xl font-display font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Payback247
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" asChild data-testid="button-login">
              <a href="/api/login">Login</a>
            </Button>
            <Button asChild data-testid="button-signup">
              <a href="/api/login">Sign Up Free</a>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-[60vh] flex items-center justify-center text-center overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary/90 to-primary/70" />
        <div className="relative z-10 max-w-4xl mx-auto px-4 text-white">
          <h2 className="text-5xl md:text-6xl font-display font-bold mb-6">
            Build Your Financial Future with P2P Network Marketing
          </h2>
          <p className="text-xl md:text-2xl mb-8 text-white/90">
            Earn ₹31,000+ through referrals, binary matching, and matrix income
          </p>
          <Button size="lg" variant="secondary" asChild data-testid="button-get-started" className="text-lg px-8">
            <a href="/api/login">
              Sign Up Free <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </Button>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <h2 className="text-headline-md text-center mb-12 font-display">How It Works</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card data-testid="card-how-step-1">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="h-8 w-8 text-primary" />
                </div>
                <CardTitle>1. Join with a Referral</CardTitle>
              </CardHeader>
              <CardContent className="text-center text-muted-foreground">
                Sign up using a referral link and choose your position (left or right). Pay the activation fee of ₹5,000 to unlock all income plans.
              </CardContent>
            </Card>

            <Card data-testid="card-how-step-2">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="h-8 w-8 text-primary" />
                </div>
                <CardTitle>2. Build Your Network</CardTitle>
              </CardHeader>
              <CardContent className="text-center text-muted-foreground">
                Refer others to join under you. Earn ₹1,000 per direct referral and qualify for binary income with 1 left + 1 right member.
              </CardContent>
            </Card>

            <Card data-testid="card-how-step-3">
              <CardHeader className="text-center pb-4">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <DollarSign className="h-8 w-8 text-primary" />
                </div>
                <CardTitle>3. Earn Multiple Incomes</CardTitle>
              </CardHeader>
              <CardContent className="text-center text-muted-foreground">
                Get binary income (₹1,000 via FIFO queue), matrix income (₹500 per level up to 5 levels), and enjoy spillover benefits.
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Income Plans */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-headline-md text-center mb-12 font-display">Income Plans</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="border-2 hover-elevate transition-shadow" data-testid="card-income-referral">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Referral Income
                </CardTitle>
                <CardDescription>Direct sponsoring rewards</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-display font-bold text-primary mb-4">₹1,000</div>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 shrink-0" />
                    <span className="text-sm">Per direct referral</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 shrink-0" />
                    <span className="text-sm">Choose left or right position</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 shrink-0" />
                    <span className="text-sm">Instant income on activation</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-2 hover-elevate transition-shadow" data-testid="card-income-binary">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Network className="h-5 w-5 text-primary" />
                  Binary Income
                </CardTitle>
                <CardDescription>FIFO Queue System - Fair for Everyone</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-display font-bold text-primary mb-4">₹1,000</div>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 shrink-0" />
                    <span className="text-sm">First-In-First-Out payment distribution</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 shrink-0" />
                    <span className="text-sm">Payment goes to first person in queue</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 shrink-0" />
                    <span className="text-sm">Everyone gets equal opportunity</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="border-2 hover-elevate transition-shadow" data-testid="card-income-matrix">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  Matrix Income
                </CardTitle>
                <CardDescription>5-level forced matrix</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-display font-bold text-primary mb-4">₹2,500</div>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 shrink-0" />
                    <span className="text-sm">₹500 per level (5 levels)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 shrink-0" />
                    <span className="text-sm">FIFO spillover system</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="h-5 w-5 text-success mt-0.5 shrink-0" />
                    <span className="text-sm">Total potential: ₹31,000</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action - Sign Up */}
      <section className="py-20 bg-gradient-to-r from-primary to-primary/80">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-3xl mx-auto text-white">
            <h2 className="text-4xl md:text-5xl font-display font-bold mb-6">
              Ready to Start Earning?
            </h2>
            <p className="text-xl md:text-2xl mb-8 text-white/90">
              Join thousands of members already building their financial freedom through our fair P2P system
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                size="lg" 
                variant="secondary" 
                asChild 
                data-testid="button-cta-signup" 
                className="text-lg px-10 py-6 h-auto"
              >
                <a href="/api/login">
                  Sign Up Now - It's Free! <ArrowRight className="ml-2 h-6 w-6" />
                </a>
              </Button>
              <div className="text-white/90 text-sm">
                <CheckCircle2 className="inline h-5 w-5 mr-2" />
                No credit card required
              </div>
            </div>
            <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-6 w-6 shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Fair Distribution</h4>
                    <p className="text-sm text-white/80">FIFO queue ensures everyone gets their turn</p>
                  </div>
                </div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-6 w-6 shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Multiple Income Streams</h4>
                    <p className="text-sm text-white/80">Earn from referrals, binary & matrix</p>
                  </div>
                </div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="h-6 w-6 shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold mb-1">Transparent System</h4>
                    <p className="text-sm text-white/80">Real-time tracking & blockchain verified</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4 max-w-3xl">
          <h2 className="text-headline-md text-center mb-12 font-display">Frequently Asked Questions</h2>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1" data-testid="faq-item-1">
              <AccordionTrigger>What is the activation fee?</AccordionTrigger>
              <AccordionContent>
                The total activation fee is ₹5,000, which includes payments for referral (₹1,000), binary (₹1,000), matrix levels (₹2,500), and admin fee (₹500). These payments activate your account and unlock all income streams.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-2" data-testid="faq-item-2">
              <AccordionTrigger>How does the binary system work?</AccordionTrigger>
              <AccordionContent>
                The binary system uses a FIFO (First-In-First-Out) queue for fair distribution. When a new user joins and makes their binary payment (₹1,000), it goes to the first person in the queue. After receiving the payment, that person is removed from the queue, and the next person moves up. Everyone gets their turn based on when they joined!
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-3" data-testid="faq-item-3">
              <AccordionTrigger>What is the matrix spillover?</AccordionTrigger>
              <AccordionContent>
                Our 5-level forced matrix uses FIFO (First In, First Out) spillover. When your direct positions are filled, new members spill over to the next available position in your downline. Each new member pays ₹500 to each of their 5 upline levels, earning you ₹500 per level.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-4" data-testid="faq-item-4">
              <AccordionTrigger>How do I receive payments?</AccordionTrigger>
              <AccordionContent>
                This is a P2P (peer-to-peer) system. Members pay each other directly using multiple methods: QR codes, bank transfer, UPI, or USDT. You'll provide your payment details in your profile, and payments are verified by receivers before confirmation.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-5" data-testid="faq-item-5">
              <AccordionTrigger>What happens if a payment is disputed?</AccordionTrigger>
              <AccordionContent>
                If a receiver doesn't confirm your payment within the time limit, it becomes a dispute. Admin will review the payment proof and resolve the dispute fairly, either confirming the payment for the sender or rejecting it for the receiver.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-display font-bold text-lg mb-4">Payback247</h3>
              <p className="text-sm text-muted-foreground">
                Building financial freedom through P2P network marketing.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">How It Works</a></li>
                <li><a href="#" className="hover:text-foreground">Income Plans</a></li>
                <li><a href="#" className="hover:text-foreground">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">Help Center</a></li>
                <li><a href="#" className="hover:text-foreground">Contact Us</a></li>
                <li><a href="#" className="hover:text-foreground">Terms of Service</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Connect</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">Facebook</a></li>
                <li><a href="#" className="hover:text-foreground">Twitter</a></li>
                <li><a href="#" className="hover:text-foreground">WhatsApp</a></li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t text-center text-sm text-muted-foreground">
            © 2024 Payback247. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
