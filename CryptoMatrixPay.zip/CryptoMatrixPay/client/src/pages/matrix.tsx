import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { TrendingUp, Users } from "lucide-react";
import type { MatrixPlacement } from "@shared/schema";

export default function Matrix() {
  const { data: matrixData } = useQuery<{
    stats: {
      totalIncome: number;
      totalMembers: number;
    };
    levels: Array<{
      level: number;
      capacity: number;
      filled: number;
      members: MatrixPlacement[];
    }>;
    queue: any[];
  }>({
    queryKey: ["/api/matrix"],
  });

  const levelCapacities = [2, 4, 8, 16, 32]; // Level 1-5

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-headline-md font-display mb-2">Matrix Income</h2>
        <p className="text-muted-foreground">5-level forced matrix with FIFO spillover</p>
      </div>

      {/* Stats Overview */}
      <div className="grid md:grid-cols-2 gap-4">
        <Card data-testid="stat-matrix-income">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Matrix Income</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-display font-bold">
              ₹{matrixData?.stats.totalIncome?.toLocaleString() || 0}
            </div>
          </CardContent>
        </Card>

        <Card data-testid="stat-matrix-members">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Members</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-display font-bold">{matrixData?.stats.totalMembers || 0}</div>
          </CardContent>
        </Card>
      </div>

      {/* Matrix Levels */}
      <Accordion type="single" collapsible className="space-y-4">
        {matrixData?.levels.map((level, index) => {
          const progress = (level.filled / level.capacity) * 100;
          return (
            <AccordionItem
              key={level.level}
              value={`level-${level.level}`}
              className="border rounded-lg px-4"
              data-testid={`level-${level.level}`}
            >
              <AccordionTrigger className="hover:no-underline">
                <div className="flex items-center justify-between w-full pr-4">
                  <div className="flex items-center gap-4">
                    <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10 text-primary font-semibold">
                      {level.level}
                    </div>
                    <div className="text-left">
                      <h4 className="font-semibold">Level {level.level}</h4>
                      <p className="text-sm text-muted-foreground">
                        {level.filled} / {level.capacity} Members
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-32">
                      <Progress value={progress} className="h-2" />
                    </div>
                    <Badge variant={level.filled === level.capacity ? "default" : "outline"}>
                      {progress.toFixed(0)}%
                    </Badge>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                {level.members.length === 0 ? (
                  <p className="text-center text-muted-foreground py-4">No members yet</p>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-4">
                    {level.members.map((member) => (
                      <div
                        key={member.id}
                        className="p-3 bg-muted rounded-lg text-center"
                        data-testid={`member-${member.id}`}
                      >
                        <div className="w-10 h-10 rounded-full bg-primary/10 mx-auto mb-2 flex items-center justify-center">
                          <Users className="h-5 w-5 text-primary" />
                        </div>
                        <p className="text-xs font-mono">{member.userId.slice(0, 8)}...</p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Pos: {member.position}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </AccordionContent>
            </AccordionItem>
          );
        })}
      </Accordion>

      {/* Global Matrix Queue */}
      <Card data-testid="card-matrix-queue">
        <CardHeader>
          <CardTitle>Global Matrix Queue</CardTitle>
        </CardHeader>
        <CardContent>
          {!matrixData?.queue?.length ? (
            <p className="text-center text-muted-foreground py-8">Queue is empty</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Position</TableHead>
                  <TableHead>User ID</TableHead>
                  <TableHead>Joined</TableHead>
                  <TableHead>Next Level</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {matrixData.queue.map((item, index) => (
                  <TableRow key={item.userId} className={item.isCurrentUser ? 'bg-primary/5' : ''}>
                    <TableCell className="font-semibold">#{index + 1}</TableCell>
                    <TableCell className="font-mono text-sm">{item.userId.slice(0, 8)}...</TableCell>
                    <TableCell>{new Date(item.joinedAt).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Badge variant="outline">Level {item.nextLevel || 1}</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
