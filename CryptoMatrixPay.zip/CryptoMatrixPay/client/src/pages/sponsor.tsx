import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Users, TrendingUp } from "lucide-react";
import type { Transaction } from "@shared/schema";

export default function Sponsor() {
  const { data: sponsorData } = useQuery<{
    totalIncome: number;
    totalReferrals: number;
    leftCount: number;
    rightCount: number;
    transactions: Transaction[];
  }>({
    queryKey: ["/api/sponsor"],
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-headline-md font-display mb-2">Sponsor Income</h2>
        <p className="text-muted-foreground">Track your direct referral earnings</p>
      </div>

      {/* Stats Overview */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card data-testid="stat-sponsor-income">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Sponsor Income</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-display font-bold">
              ₹{sponsorData?.totalIncome?.toLocaleString() || 0}
            </div>
          </CardContent>
        </Card>

        <Card data-testid="stat-total-referrals">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Referrals</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-display font-bold">{sponsorData?.totalReferrals || 0}</div>
          </CardContent>
        </Card>

        <Card data-testid="stat-left-referrals">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Left Team</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-display font-bold">{sponsorData?.leftCount || 0}</div>
          </CardContent>
        </Card>

        <Card data-testid="stat-right-referrals">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Right Team</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-display font-bold">{sponsorData?.rightCount || 0}</div>
          </CardContent>
        </Card>
      </div>

      {/* Sponsor Income History */}
      <Card data-testid="card-sponsor-history">
        <CardHeader>
          <CardTitle>Sponsor Income History</CardTitle>
        </CardHeader>
        <CardContent>
          {!sponsorData?.transactions?.length ? (
            <div className="text-center py-12">
              <Users className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-semibold mb-2">No Referral Income Yet</h3>
              <p className="text-sm text-muted-foreground">
                Share your referral links to start earning ₹1,000 per direct referral
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>From User</TableHead>
                  <TableHead>Position</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sponsorData.transactions.map((transaction) => (
                  <TableRow key={transaction.id}>
                    <TableCell>{new Date(transaction.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell className="font-mono text-sm">
                      {transaction.fromUserId?.slice(0, 8)}...
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {transaction.description?.includes('left') ? 'Left' : 'Right'}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right font-semibold text-success">
                      +₹{transaction.amount}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
