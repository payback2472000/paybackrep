import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { TrendingUp, Users, DollarSign, Award } from "lucide-react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { useState } from "react";

export default function Analytics() {
  const [timeRange, setTimeRange] = useState("7d");

  // Mock data for charts - replace with real API calls
  const incomeData = [
    { date: "Oct 10", referral: 2000, binary: 1000, matrix: 1800 },
    { date: "Oct 11", referral: 3000, binary: 2000, matrix: 2400 },
    { date: "Oct 12", referral: 2500, binary: 1500, matrix: 2100 },
    { date: "Oct 13", referral: 4000, binary: 3000, matrix: 3000 },
    { date: "Oct 14", referral: 3500, binary: 2500, matrix: 2700 },
    { date: "Oct 15", referral: 5000, binary: 4000, matrix: 3600 },
    { date: "Oct 16", referral: 4500, binary: 3500, matrix: 3300 },
  ];

  const networkGrowthData = [
    { month: "Jun", users: 15 },
    { month: "Jul", users: 32 },
    { month: "Aug", users: 58 },
    { month: "Sep", users: 94 },
    { month: "Oct", users: 147 },
  ];

  const incomeDistributionData = [
    { name: "Referral Income", value: 45000, color: "#3B82F6" },
    { name: "Binary Income", value: 32000, color: "#10B981" },
    { name: "Matrix Income", value: 28000, color: "#F59E0B" },
  ];

  const topEarnersData = [
    { id: "1", name: "John Doe", totalIncome: 125000, rank: 1 },
    { id: "2", name: "Jane Smith", totalIncome: 98000, rank: 2 },
    { id: "3", name: "Mike Johnson", totalIncome: 87000, rank: 3 },
    { id: "4", name: "Sarah Williams", totalIncome: 76000, rank: 4 },
    { id: "5", name: "David Brown", totalIncome: 65000, rank: 5 },
  ];

  const stats = [
    {
      title: "Total Income",
      value: "₹105,000",
      change: "+12.5%",
      icon: DollarSign,
      color: "text-green-500",
    },
    {
      title: "Network Size",
      value: "147",
      change: "+23",
      icon: Users,
      color: "text-blue-500",
    },
    {
      title: "Active Members",
      value: "89",
      change: "+15",
      icon: TrendingUp,
      color: "text-purple-500",
    },
    {
      title: "Team Performance",
      value: "87%",
      change: "+5%",
      icon: Award,
      color: "text-orange-500",
    },
  ];

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" data-testid="heading-analytics">Analytics Dashboard</h1>
          <p className="text-muted-foreground">Track your income, network growth, and team performance</p>
        </div>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-40" data-testid="select-timerange">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7d">Last 7 days</SelectItem>
            <SelectItem value="30d">Last 30 days</SelectItem>
            <SelectItem value="90d">Last 90 days</SelectItem>
            <SelectItem value="1y">Last year</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.title} data-testid={`card-stat-${stat.title.toLowerCase().replace(/ /g, '-')}`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                  <p className="text-2xl font-bold mt-1">{stat.value}</p>
                  <p className={`text-sm mt-1 ${stat.color}`}>{stat.change} from last period</p>
                </div>
                <stat.icon className={`h-8 w-8 ${stat.color}`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <Tabs defaultValue="income" className="space-y-4">
        <TabsList>
          <TabsTrigger value="income" data-testid="tab-income">Income Trends</TabsTrigger>
          <TabsTrigger value="network" data-testid="tab-network">Network Growth</TabsTrigger>
          <TabsTrigger value="distribution" data-testid="tab-distribution">Income Distribution</TabsTrigger>
        </TabsList>

        <TabsContent value="income" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Income Trends</CardTitle>
              <CardDescription>Daily income breakdown by source</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <LineChart data={incomeData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="date" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="referral"
                    stroke="#3B82F6"
                    strokeWidth={2}
                    name="Referral Income"
                  />
                  <Line
                    type="monotone"
                    dataKey="binary"
                    stroke="#10B981"
                    strokeWidth={2}
                    name="Binary Income"
                  />
                  <Line
                    type="monotone"
                    dataKey="matrix"
                    stroke="#F59E0B"
                    strokeWidth={2}
                    name="Matrix Income"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="network" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Network Growth</CardTitle>
              <CardDescription>Total network members over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={networkGrowthData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="month" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                  <Bar dataKey="users" fill="#3B82F6" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="distribution" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Income Distribution</CardTitle>
              <CardDescription>Breakdown of income by source</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <PieChart>
                  <Pie
                    data={incomeDistributionData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={120}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {incomeDistributionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Top Earners */}
      <Card>
        <CardHeader>
          <CardTitle>Top Earners</CardTitle>
          <CardDescription>Leading members in your network</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {topEarnersData.map((earner) => (
              <div
                key={earner.id}
                className="flex items-center justify-between p-4 rounded-lg bg-muted/50"
                data-testid={`earner-${earner.rank}`}
              >
                <div className="flex items-center gap-4">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary text-primary-foreground font-bold">
                    {earner.rank}
                  </div>
                  <div>
                    <p className="font-semibold">{earner.name}</p>
                    <p className="text-sm text-muted-foreground">Rank #{earner.rank}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-lg">₹{earner.totalIncome.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">Total Income</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
