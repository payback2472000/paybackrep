import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ArrowDownRight, ArrowUpRight } from "lucide-react";
import type { Transaction } from "@shared/schema";

export default function Transactions() {
  const { data: transactions = [] } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  const getTypeBadge = (type: string) => {
    const variants: Record<string, { variant: "default" | "secondary" | "outline", label: string }> = {
      referral_income: { variant: "default", label: "Referral" },
      binary_income: { variant: "default", label: "Binary" },
      matrix_income: { variant: "default", label: "Matrix" },
      admin_income: { variant: "secondary", label: "Admin" },
    };
    const config = variants[type] || variants.referral_income;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const totalIncome = transactions.reduce((sum, t) => sum + parseFloat(t.amount.toString()), 0);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-headline-md font-display mb-2">Transaction History</h2>
        <p className="text-muted-foreground">View all your earnings and transactions</p>
      </div>

      {/* Total Income Card */}
      <Card className="bg-gradient-to-br from-primary to-primary/60 text-white border-0" data-testid="card-total-income">
        <CardHeader>
          <CardTitle className="text-white/90">Total Earnings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-4xl font-display font-bold">₹{totalIncome.toLocaleString()}</div>
          <p className="text-sm text-white/80 mt-2">{transactions.length} total transactions</p>
        </CardContent>
      </Card>

      {/* Transactions Table */}
      <Card data-testid="card-transactions">
        <CardHeader>
          <CardTitle>All Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          {transactions.length === 0 ? (
            <div className="text-center py-12">
              <ArrowDownRight className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-lg font-semibold mb-2">No Transactions Yet</h3>
              <p className="text-sm text-muted-foreground">
                Your earnings will appear here once you start receiving income
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>From User</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {transactions.map((transaction) => (
                  <TableRow key={transaction.id}>
                    <TableCell className="whitespace-nowrap">
                      {new Date(transaction.createdAt).toLocaleDateString()}
                    </TableCell>
                    <TableCell>{getTypeBadge(transaction.transactionType)}</TableCell>
                    <TableCell className="max-w-xs truncate">
                      {transaction.description || 'N/A'}
                    </TableCell>
                    <TableCell className="font-mono text-sm">
                      {transaction.fromUserId ? `${transaction.fromUserId.slice(0, 8)}...` : 'System'}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <ArrowUpRight className="h-4 w-4 text-success" />
                        <span className="font-semibold text-success">+₹{transaction.amount}</span>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
