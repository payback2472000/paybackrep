import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Network, Users, TrendingUp, CheckCircle2, XCircle } from "lucide-react";
import type { BinaryTree, BinaryMatch } from "@shared/schema";

export default function Binary() {
  const { data: binaryData } = useQuery<{
    tree: BinaryTree;
    stats: {
      totalIncome: number;
      leftCount: number;
      rightCount: number;
      pendingIncome: number;
      isQualified: boolean;
    };
    matches: BinaryMatch[];
    queue: any[];
  }>({
    queryKey: ["/api/binary"],
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-headline-md font-display mb-2">Binary Income (FIFO Queue System)</h2>
        <p className="text-muted-foreground">Binary payments (₹1000) go to the first person in queue. Fair distribution for everyone!</p>
      </div>

      {/* Stats Overview */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card data-testid="stat-binary-income">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Binary Income</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-display font-bold">₹{binaryData?.stats.totalIncome?.toLocaleString() || 0}</div>
          </CardContent>
        </Card>

        <Card data-testid="stat-left-team">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Left Team</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-display font-bold">{binaryData?.stats.leftCount || 0}</div>
          </CardContent>
        </Card>

        <Card data-testid="stat-right-team">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Right Team</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-display font-bold">{binaryData?.stats.rightCount || 0}</div>
          </CardContent>
        </Card>

        <Card data-testid="stat-pending-income">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Pending Income</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-display font-bold">₹{binaryData?.stats.pendingIncome?.toLocaleString() || 0}</div>
          </CardContent>
        </Card>
      </div>

      {/* Qualification Status */}
      <Card data-testid="card-qualification">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            {binaryData?.stats.isQualified ? (
              <CheckCircle2 className="h-5 w-5 text-success" />
            ) : (
              <XCircle className="h-5 w-5 text-muted-foreground" />
            )}
            Binary Qualification
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className={`p-4 rounded-lg ${binaryData?.stats.isQualified ? 'bg-success/10' : 'bg-muted'}`}>
            <p className="text-sm">
              {binaryData?.stats.isQualified
                ? 'You are qualified! You have at least 1 paid member on both left and right.'
                : 'To qualify for binary income, you need at least 1 paid sponsor on your left and 1 on your right.'}
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-4 mt-4">
            <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${(binaryData?.stats.leftCount || 0) > 0 ? 'bg-success text-white' : 'bg-muted-foreground/20'}`}>
                <Users className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm font-medium">Left: {binaryData?.stats.leftCount || 0}</p>
                <p className="text-xs text-muted-foreground">Members</p>
              </div>
            </div>
            <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${(binaryData?.stats.rightCount || 0) > 0 ? 'bg-success text-white' : 'bg-muted-foreground/20'}`}>
                <Users className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm font-medium">Right: {binaryData?.stats.rightCount || 0}</p>
                <p className="text-xs text-muted-foreground">Members</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Matched Pairs History */}
      <Card data-testid="card-matches">
        <CardHeader>
          <CardTitle>Matched Pairs History</CardTitle>
        </CardHeader>
        <CardContent>
          {!binaryData?.matches?.length ? (
            <p className="text-center text-muted-foreground py-8">No matches yet</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Left Member</TableHead>
                  <TableHead>Right Member</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {binaryData.matches.map((match) => (
                  <TableRow key={match.id}>
                    <TableCell>{new Date(match.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell className="font-mono text-sm">{match.leftUserId.slice(0, 8)}...</TableCell>
                    <TableCell className="font-mono text-sm">{match.rightUserId.slice(0, 8)}...</TableCell>
                    <TableCell className="text-right font-semibold">₹{match.amount}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Global Binary Payment Queue (FIFO System) */}
      <Card data-testid="card-queue">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="h-5 w-5" />
            Binary Payment Queue (FIFO System)
          </CardTitle>
          <p className="text-sm text-muted-foreground mt-1">
            Binary payments (₹1000) go to the first person in queue, then they're removed
          </p>
        </CardHeader>
        <CardContent>
          {!binaryData?.queue?.length ? (
            <p className="text-center text-muted-foreground py-8">Queue is empty</p>
          ) : (
            <>
              {/* Next to Receive Indicator */}
              {binaryData.queue.length > 0 && (
                <div className="mb-4 p-4 bg-success/10 border-2 border-success rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="h-12 w-12 rounded-full bg-success flex items-center justify-center text-white">
                      <TrendingUp className="h-6 w-6" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-muted-foreground">Next to Receive Binary Payment</p>
                      <p className="font-semibold text-lg">{binaryData.queue[0].name}</p>
                      <p className="text-xs text-muted-foreground font-mono">{binaryData.queue[0].userId.slice(0, 8)}...</p>
                    </div>
                    <Badge className="bg-success text-white">₹1000</Badge>
                  </div>
                </div>
              )}

              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Queue Position</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Joined Queue</TableHead>
                    <TableHead>Team Size</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {binaryData.queue.map((item, index) => (
                    <TableRow 
                      key={item.userId} 
                      className={`
                        ${item.isCurrentUser ? 'bg-primary/5' : ''} 
                        ${index === 0 ? 'border-l-4 border-l-success' : ''}
                      `} 
                      data-testid={`queue-row-${index}`}
                    >
                      <TableCell className="font-semibold">
                        <div className="flex items-center gap-2">
                          #{index + 1}
                          {index === 0 && (
                            <Badge variant="default" className="bg-success text-xs" data-testid="badge-next-receiver">
                              NEXT
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-medium">{item.name}</span>
                          <span className="font-mono text-xs text-muted-foreground">{item.userId.slice(0, 8)}...</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-sm">{new Date(item.joinedAt).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Badge variant="outline" className="font-mono">L: {item.leftCount}</Badge>
                          <Badge variant="outline" className="font-mono">R: {item.rightCount}</Badge>
                        </div>
                      </TableCell>
                      <TableCell>
                        {item.isQualified ? (
                          <Badge variant="default" data-testid={`status-qualified-${index}`}>✓ Qualified</Badge>
                        ) : (
                          <Badge variant="outline" data-testid={`status-not-qualified-${index}`}>Not Qualified</Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
