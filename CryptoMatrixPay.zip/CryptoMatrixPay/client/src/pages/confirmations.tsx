import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Clock, Eye, CheckCircle2, XCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Payment, User } from "@shared/schema";

interface PendingConfirmation extends Payment {
  sender: User;
}

export default function Confirmations() {
  const { toast } = useToast();
  const [selectedProof, setSelectedProof] = useState<string | null>(null);

  const { data: pendingPayments = [] } = useQuery<PendingConfirmation[]>({
    queryKey: ["/api/confirmations/pending"],
  });

  const confirmMutation = useMutation({
    mutationFn: async (paymentId: string) => {
      return await apiRequest("POST", `/api/confirmations/${paymentId}/confirm`, {});
    },
    onSuccess: () => {
      toast({
        title: "Payment Confirmed",
        description: "The payment has been confirmed successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/confirmations/pending"] });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async (paymentId: string) => {
      return await apiRequest("POST", `/api/confirmations/${paymentId}/reject`, {});
    },
    onSuccess: () => {
      toast({
        title: "Payment Rejected",
        description: "The payment has been rejected",
        variant: "destructive",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/confirmations/pending"] });
    },
  });

  const formatTimeRemaining = (expiresAt: Date | string) => {
    const now = new Date();
    const expiry = new Date(expiresAt);
    const diff = expiry.getTime() - now.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-headline-md font-display mb-2">Payment Confirmations</h2>
        <p className="text-muted-foreground">
          Verify payments from other members ({pendingPayments.length} pending)
        </p>
      </div>

      {pendingPayments.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <CheckCircle2 className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">No Pending Confirmations</h3>
            <p className="text-sm text-muted-foreground">
              You'll see payment confirmations here when members pay you
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {pendingPayments.map((payment) => (
            <Card key={payment.id} data-testid={`confirmation-card-${payment.id}`}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-lg font-semibold text-primary">
                        {payment.sender.firstName?.[0]}{payment.sender.lastName?.[0]}
                      </span>
                    </div>
                    <div>
                      <CardTitle className="text-lg">
                        {payment.sender.firstName} {payment.sender.lastName}
                      </CardTitle>
                      <p className="text-sm text-muted-foreground">
                        {payment.paymentType.replace(/_/g, ' ')} Payment
                      </p>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-warning border-warning">
                    <Clock className="h-3 w-3 mr-1" />
                    {payment.expiresAt && formatTimeRemaining(payment.expiresAt)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 p-4 bg-muted/50 rounded-lg">
                  <div>
                    <p className="text-sm text-muted-foreground">Amount</p>
                    <p className="text-xl font-display font-semibold">₹{payment.amount}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Transaction ID</p>
                    <p className="font-mono text-sm">{payment.transactionId || 'N/A'}</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  {payment.proofUrl && (
                    <Button
                      variant="outline"
                      className="flex-1"
                      onClick={() => setSelectedProof(payment.proofUrl || null)}
                      data-testid="button-view-proof"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      View Proof
                    </Button>
                  )}
                  <Button
                    variant="default"
                    className="flex-1"
                    onClick={() => confirmMutation.mutate(payment.id)}
                    disabled={confirmMutation.isPending}
                    data-testid="button-confirm"
                  >
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Confirm
                  </Button>
                  <Button
                    variant="destructive"
                    className="flex-1"
                    onClick={() => rejectMutation.mutate(payment.id)}
                    disabled={rejectMutation.isPending}
                    data-testid="button-reject"
                  >
                    <XCircle className="h-4 w-4 mr-2" />
                    Reject
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Dialog open={!!selectedProof} onOpenChange={() => setSelectedProof(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Payment Proof</DialogTitle>
          </DialogHeader>
          {selectedProof && (
            <img
              src={selectedProof}
              alt="Payment proof"
              className="w-full rounded-lg"
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
