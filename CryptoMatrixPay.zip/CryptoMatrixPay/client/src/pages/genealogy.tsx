import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { User, Search, ChevronDown, ChevronRight } from "lucide-react";

interface TreeNode {
  id: string;
  name: string;
  status: 'active' | 'inactive' | 'pending';
  joinDate: string;
  totalIncome: number;
  left?: TreeNode;
  right?: TreeNode;
  children?: TreeNode[];
}

function BinaryTreeNode({ node, level = 0 }: { node: TreeNode | undefined; level?: number }) {
  const [expanded, setExpanded] = useState(level < 2);

  if (!node) {
    return (
      <div className="flex flex-col items-center">
        <div className="w-32 h-24 border-2 border-dashed border-muted rounded-lg flex items-center justify-center">
          <span className="text-xs text-muted-foreground">Empty</span>
        </div>
      </div>
    );
  }

  const statusColors = {
    active: 'bg-green-500',
    inactive: 'bg-gray-500',
    pending: 'bg-yellow-500',
  };

  return (
    <div className="flex flex-col items-center">
      {/* Node Card */}
      <Card className="w-40 mb-4 hover-elevate cursor-pointer" data-testid={`tree-node-${node.id}`}>
        <CardContent className="p-3">
          <div className="flex items-center gap-2 mb-2">
            <div className={`h-2 w-2 rounded-full ${statusColors[node.status]}`} />
            <span className="text-sm font-semibold truncate">{node.name}</span>
          </div>
          <p className="text-xs text-muted-foreground">ID: {node.id}</p>
          <p className="text-xs text-muted-foreground">Income: ₹{node.totalIncome.toLocaleString()}</p>
          <Badge variant={node.status === 'active' ? 'default' : 'secondary'} className="mt-2 text-xs">
            {node.status}
          </Badge>
        </CardContent>
      </Card>

      {/* Children */}
      {(node.left || node.right) && (
        <>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setExpanded(!expanded)}
            className="mb-2"
            data-testid={`toggle-expand-${node.id}`}
          >
            {expanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </Button>

          {expanded && (
            <div className="flex gap-8 relative">
              {/* Connection Lines */}
              <div className="absolute top-0 left-1/2 w-0.5 h-4 bg-border -translate-x-1/2" />
              <div className="absolute top-4 left-0 right-0 h-0.5 bg-border" />
              
              <div className="relative">
                <div className="absolute top-0 left-1/2 w-0.5 h-4 bg-border -translate-x-1/2" />
                <div className="pt-4">
                  <div className="text-xs text-muted-foreground text-center mb-2">Left</div>
                  <BinaryTreeNode node={node.left} level={level + 1} />
                </div>
              </div>

              <div className="relative">
                <div className="absolute top-0 left-1/2 w-0.5 h-4 bg-border -translate-x-1/2" />
                <div className="pt-4">
                  <div className="text-xs text-muted-foreground text-center mb-2">Right</div>
                  <BinaryTreeNode node={node.right} level={level + 1} />
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function MatrixTreeLevel({ nodes, level }: { nodes: TreeNode[]; level: number }) {
  return (
    <div className="mb-6">
      <h3 className="text-sm font-semibold mb-3">Level {level}</h3>
      <div className="flex flex-wrap gap-3">
        {nodes.map((node) => (
          <Card key={node.id} className="w-36 hover-elevate" data-testid={`matrix-node-${node.id}`}>
            <CardContent className="p-3">
              <div className="flex items-center gap-2 mb-1">
                <User className="h-3 w-3" />
                <span className="text-xs font-semibold truncate">{node.name}</span>
              </div>
              <p className="text-xs text-muted-foreground">ID: {node.id}</p>
              <Badge variant={node.status === 'active' ? 'default' : 'secondary'} className="mt-2 text-xs">
                {node.status}
              </Badge>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

export default function Genealogy() {
  const [searchQuery, setSearchQuery] = useState("");

  // Mock data - replace with real API
  const binaryTreeData: TreeNode = {
    id: "USER001",
    name: "You",
    status: "active",
    joinDate: "2024-01-15",
    totalIncome: 125000,
    left: {
      id: "USER002",
      name: "John Doe",
      status: "active",
      joinDate: "2024-02-01",
      totalIncome: 45000,
      left: {
        id: "USER004",
        name: "Alice Smith",
        status: "active",
        joinDate: "2024-03-10",
        totalIncome: 15000,
      },
      right: {
        id: "USER005",
        name: "Bob Johnson",
        status: "pending",
        joinDate: "2024-03-15",
        totalIncome: 0,
      },
    },
    right: {
      id: "USER003",
      name: "Jane Williams",
      status: "active",
      joinDate: "2024-02-10",
      totalIncome: 38000,
      left: {
        id: "USER006",
        name: "Charlie Brown",
        status: "active",
        joinDate: "2024-03-20",
        totalIncome: 12000,
      },
    },
  };

  const matrixData = [
    [
      { id: "USER001", name: "You", status: "active" as const, joinDate: "2024-01-15", totalIncome: 125000 },
      { id: "USER002", name: "John Doe", status: "active" as const, joinDate: "2024-02-01", totalIncome: 45000 },
    ],
    [
      { id: "USER003", name: "Jane Williams", status: "active" as const, joinDate: "2024-02-10", totalIncome: 38000 },
      { id: "USER004", name: "Alice Smith", status: "active" as const, joinDate: "2024-03-10", totalIncome: 15000 },
      { id: "USER005", name: "Bob Johnson", status: "pending" as const, joinDate: "2024-03-15", totalIncome: 0 },
      { id: "USER006", name: "Charlie Brown", status: "active" as const, joinDate: "2024-03-20", totalIncome: 12000 },
    ],
    [
      { id: "USER007", name: "David Lee", status: "active" as const, joinDate: "2024-04-01", totalIncome: 8000 },
      { id: "USER008", name: "Emma Davis", status: "inactive" as const, joinDate: "2024-04-05", totalIncome: 5000 },
    ],
  ];

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold" data-testid="heading-genealogy">Network Genealogy</h1>
          <p className="text-muted-foreground">Visualize your complete network structure</p>
        </div>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search by name or ID..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="pl-9"
          data-testid="input-search-genealogy"
        />
      </div>

      {/* Tree Tabs */}
      <Tabs defaultValue="binary" className="space-y-6">
        <TabsList>
          <TabsTrigger value="binary" data-testid="tab-binary-tree">Binary Tree</TabsTrigger>
          <TabsTrigger value="matrix" data-testid="tab-matrix-tree">Matrix Tree</TabsTrigger>
        </TabsList>

        <TabsContent value="binary" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Binary Structure</CardTitle>
              <CardDescription>Your binary network tree with left and right branches</CardDescription>
            </CardHeader>
            <CardContent className="overflow-x-auto pb-8">
              <div className="inline-block min-w-full">
                <BinaryTreeNode node={binaryTreeData} />
              </div>
            </CardContent>
          </Card>

          {/* Legend */}
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-green-500" />
                  <span className="text-sm">Active</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-yellow-500" />
                  <span className="text-sm">Pending</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 rounded-full bg-gray-500" />
                  <span className="text-sm">Inactive</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="matrix" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Matrix Structure</CardTitle>
              <CardDescription>5-level matrix placement with FIFO spillover</CardDescription>
            </CardHeader>
            <CardContent>
              {matrixData.map((levelNodes, index) => (
                <MatrixTreeLevel key={index} nodes={levelNodes} level={index + 1} />
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Network Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardContent className="p-6">
            <p className="text-sm text-muted-foreground">Total Network</p>
            <p className="text-3xl font-bold mt-1">147</p>
            <p className="text-sm text-green-500 mt-1">+23 this month</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <p className="text-sm text-muted-foreground">Active Members</p>
            <p className="text-3xl font-bold mt-1">89</p>
            <p className="text-sm text-green-500 mt-1">60.5% activation rate</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-6">
            <p className="text-sm text-muted-foreground">Network Depth</p>
            <p className="text-3xl font-bold mt-1">5 Levels</p>
            <p className="text-sm text-muted-foreground mt-1">Maximum reached</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
