import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User as UserIcon, Wallet, Upload } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  
  const [personalInfo, setPersonalInfo] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    phone: user?.phone || '',
  });

  const [paymentInfo, setPaymentInfo] = useState({
    bankAccountName: user?.bankAccountName || '',
    bankAccount: user?.bankAccount || '',
    bankIfsc: user?.bankIfsc || '',
    upiId: user?.upiId || '',
    usdtAddress: user?.usdtAddress || '',
  });

  const [passwordInfo, setPasswordInfo] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAvatarFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("PUT", "/api/profile", data);
    },
    onSuccess: () => {
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
    },
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-headline-md font-display mb-2">Profile Settings</h2>
        <p className="text-muted-foreground">Manage your account and payment details</p>
      </div>

      {/* Profile Header */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center gap-6">
            <div className="relative">
              <Avatar className="w-20 h-20">
                <AvatarImage src={avatarPreview || user?.avatarUrl || user?.profileImageUrl || ''} />
                <AvatarFallback className="text-2xl bg-primary/10 text-primary">
                  {user?.firstName?.[0]}{user?.lastName?.[0]}
                </AvatarFallback>
              </Avatar>
              <label htmlFor="avatar-upload" className="absolute bottom-0 right-0 p-1.5 bg-primary text-primary-foreground rounded-full cursor-pointer hover-elevate">
                <Upload className="h-3 w-3" />
                <input
                  id="avatar-upload"
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleAvatarChange}
                  data-testid="input-avatar"
                />
              </label>
            </div>
            <div>
              <h3 className="text-xl font-semibold">
                {user?.firstName} {user?.lastName}
              </h3>
              <p className="text-sm text-muted-foreground">{user?.email}</p>
              <p className="text-xs text-muted-foreground font-mono mt-1">ID: {user?.id.slice(0, 12)}...</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="personal" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="personal" data-testid="tab-personal">
            <UserIcon className="h-4 w-4 mr-2" />
            Personal Info
          </TabsTrigger>
          <TabsTrigger value="payment" data-testid="tab-payment">
            <Wallet className="h-4 w-4 mr-2" />
            Payment Details
          </TabsTrigger>
          <TabsTrigger value="security" data-testid="tab-security">
            <UserIcon className="h-4 w-4 mr-2" />
            Security
          </TabsTrigger>
        </TabsList>

        <TabsContent value="personal">
          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="first-name">First Name</Label>
                  <Input
                    id="first-name"
                    value={personalInfo.firstName}
                    onChange={(e) => setPersonalInfo({ ...personalInfo, firstName: e.target.value })}
                    data-testid="input-first-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="last-name">Last Name</Label>
                  <Input
                    id="last-name"
                    value={personalInfo.lastName}
                    onChange={(e) => setPersonalInfo({ ...personalInfo, lastName: e.target.value })}
                    data-testid="input-last-name"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={personalInfo.email}
                  onChange={(e) => setPersonalInfo({ ...personalInfo, email: e.target.value })}
                  data-testid="input-email"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  value={personalInfo.phone}
                  onChange={(e) => setPersonalInfo({ ...personalInfo, phone: e.target.value })}
                  data-testid="input-phone"
                />
              </div>

              <Button
                onClick={() => updateProfileMutation.mutate(personalInfo)}
                disabled={updateProfileMutation.isPending}
                data-testid="button-save-personal"
              >
                {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payment">
          <Card>
            <CardHeader>
              <CardTitle>Payment Receiving Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="bank-account-name">Account Holder Name</Label>
                <Input
                  id="bank-account-name"
                  value={paymentInfo.bankAccountName}
                  onChange={(e) => setPaymentInfo({ ...paymentInfo, bankAccountName: e.target.value })}
                  placeholder="Full name as per bank account"
                  data-testid="input-bank-account-name"
                />
              </div>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="bank-account">Bank Account Number</Label>
                  <Input
                    id="bank-account"
                    value={paymentInfo.bankAccount}
                    onChange={(e) => setPaymentInfo({ ...paymentInfo, bankAccount: e.target.value })}
                    placeholder="Account Number"
                    data-testid="input-bank-account"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bank-ifsc">IFSC Code</Label>
                  <Input
                    id="bank-ifsc"
                    value={paymentInfo.bankIfsc}
                    onChange={(e) => setPaymentInfo({ ...paymentInfo, bankIfsc: e.target.value })}
                    placeholder="HDFC0001234"
                    data-testid="input-bank-ifsc"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="upi-id">UPI ID</Label>
                <Input
                  id="upi-id"
                  value={paymentInfo.upiId}
                  onChange={(e) => setPaymentInfo({ ...paymentInfo, upiId: e.target.value })}
                  placeholder="yourname@upi"
                  data-testid="input-upi-id"
                />
                <p className="text-xs text-muted-foreground">
                  Your UPI QR code will be auto-generated for receiving payments
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="usdt-address">USDT (BEP-20) Address</Label>
                <Input
                  id="usdt-address"
                  value={paymentInfo.usdtAddress}
                  onChange={(e) => setPaymentInfo({ ...paymentInfo, usdtAddress: e.target.value })}
                  placeholder="0x..."
                  className="font-mono text-sm"
                  data-testid="input-usdt-address"
                />
              </div>

              <Button
                onClick={() => updateProfileMutation.mutate(paymentInfo)}
                disabled={updateProfileMutation.isPending}
                data-testid="button-save-payment"
              >
                {updateProfileMutation.isPending ? "Saving..." : "Save Payment Details"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security">
          <Card>
            <CardHeader>
              <CardTitle>Change Password</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="current-password">Current Password</Label>
                <Input
                  id="current-password"
                  type="password"
                  value={passwordInfo.currentPassword}
                  onChange={(e) => setPasswordInfo({ ...passwordInfo, currentPassword: e.target.value })}
                  placeholder="Enter current password"
                  data-testid="input-current-password"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="new-password">New Password</Label>
                <Input
                  id="new-password"
                  type="password"
                  value={passwordInfo.newPassword}
                  onChange={(e) => setPasswordInfo({ ...passwordInfo, newPassword: e.target.value })}
                  placeholder="Enter new password"
                  data-testid="input-new-password"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirm-password">Confirm New Password</Label>
                <Input
                  id="confirm-password"
                  type="password"
                  value={passwordInfo.confirmPassword}
                  onChange={(e) => setPasswordInfo({ ...passwordInfo, confirmPassword: e.target.value })}
                  placeholder="Confirm new password"
                  data-testid="input-confirm-password"
                />
              </div>

              <Button
                onClick={() => {
                  if (passwordInfo.newPassword !== passwordInfo.confirmPassword) {
                    toast({ title: "Error", description: "Passwords do not match", variant: "destructive" });
                    return;
                  }
                  updateProfileMutation.mutate({ password: passwordInfo.newPassword });
                  setPasswordInfo({ currentPassword: '', newPassword: '', confirmPassword: '' });
                }}
                disabled={!passwordInfo.currentPassword || !passwordInfo.newPassword || updateProfileMutation.isPending}
                data-testid="button-change-password"
              >
                {updateProfileMutation.isPending ? "Updating..." : "Change Password"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
