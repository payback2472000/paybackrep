import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DollarSign, Users, Network, TrendingUp, Copy, Share2, CheckCircle2, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import type { User, Transaction } from "@shared/schema";

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: stats } = useQuery<{
    totalIncome: number;
    sponsorIncome: number;
    binaryIncome: number;
    matrixIncome: number;
  }>({
    queryKey: ["/api/stats"],
  });

  const referralLink = user ? `https://payback247.com/?ref=${user.id}&pos=left` : "";
  const referralLinkRight = user ? `https://payback247.com/?ref=${user.id}&pos=right` : "";

  const copyToClipboard = (text: string, side: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: `${side} referral link copied to clipboard`,
    });
  };

  const shareWhatsApp = (link: string, side: string) => {
    window.open(`https://wa.me/?text=Join Payback247 on my ${side} team: ${encodeURIComponent(link)}`);
  };

  const statCards = [
    {
      title: "Total Income",
      value: `₹${stats?.totalIncome?.toLocaleString() || 0}`,
      icon: DollarSign,
      gradient: "from-primary to-primary/60",
      testId: "stat-total-income"
    },
    {
      title: "Sponsor Income",
      value: `₹${stats?.sponsorIncome?.toLocaleString() || 0}`,
      icon: Users,
      gradient: "from-success to-success/60",
      testId: "stat-sponsor-income"
    },
    {
      title: "Binary Income",
      value: `₹${stats?.binaryIncome?.toLocaleString() || 0}`,
      icon: Network,
      gradient: "from-info to-info/60",
      testId: "stat-binary-income"
    },
    {
      title: "Matrix Income",
      value: `₹${stats?.matrixIncome?.toLocaleString() || 0}`,
      icon: TrendingUp,
      gradient: "from-warning to-warning/60",
      testId: "stat-matrix-income"
    },
  ];

  return (
    <div className="space-y-8">
      {/* Account Status Banner */}
      <div
        className={`p-6 rounded-lg flex items-center justify-between ${
          user?.accountStatus === 'active'
            ? 'bg-success/10 border border-success/20'
            : 'bg-warning/10 border border-warning/20'
        }`}
        data-testid="account-status-banner"
      >
        <div className="flex items-center gap-3">
          {user?.accountStatus === 'active' ? (
            <CheckCircle2 className="h-6 w-6 text-success" />
          ) : (
            <AlertCircle className="h-6 w-6 text-warning" />
          )}
          <div>
            <h3 className="font-semibold text-lg">
              {user?.accountStatus === 'active' ? 'Account Active' : 'Pending Activation'}
            </h3>
            <p className="text-sm text-muted-foreground">
              {user?.accountStatus === 'active'
                ? 'Your account is fully activated and earning'
                : 'Complete your activation payments to start earning'}
            </p>
          </div>
        </div>
        {user?.accountStatus !== 'active' && (
          <Button variant="outline" data-testid="button-complete-activation">
            Complete Activation
          </Button>
        )}
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat) => (
          <Card
            key={stat.title}
            className={`overflow-hidden bg-gradient-to-br ${stat.gradient} text-white border-0`}
            data-testid={stat.testId}
          >
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-white/90">{stat.title}</CardTitle>
              <stat.icon className="h-5 w-5 text-white/80" />
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-display font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Referral Links Section */}
      <Card data-testid="card-referral-links">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Share2 className="h-5 w-5" />
            Grow Your Network
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Left Position */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold">Left Position</h4>
              <Badge variant="outline">Left Team</Badge>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={referralLink}
                readOnly
                className="flex-1 px-4 py-2 bg-muted rounded-md text-sm font-mono"
                data-testid="input-referral-left"
              />
              <Button
                variant="outline"
                size="icon"
                onClick={() => copyToClipboard(referralLink, "Left")}
                data-testid="button-copy-left"
              >
                <Copy className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={() => shareWhatsApp(referralLink, "left")}
                data-testid="button-share-left"
              >
                <Share2 className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Right Position */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold">Right Position</h4>
              <Badge variant="outline">Right Team</Badge>
            </div>
            <div className="flex gap-2">
              <input
                type="text"
                value={referralLinkRight}
                readOnly
                className="flex-1 px-4 py-2 bg-muted rounded-md text-sm font-mono"
                data-testid="input-referral-right"
              />
              <Button
                variant="outline"
                size="icon"
                onClick={() => copyToClipboard(referralLinkRight, "Right")}
                data-testid="button-copy-right"
              >
                <Copy className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={() => shareWhatsApp(referralLinkRight, "right")}
                data-testid="button-share-right"
              >
                <Share2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-3 gap-4">
        <Card className="hover-elevate cursor-pointer transition-shadow" data-testid="card-action-sponsor">
          <CardContent className="pt-6">
            <Users className="h-10 w-10 text-primary mb-3" />
            <h4 className="font-semibold mb-2">Sponsor Members</h4>
            <p className="text-sm text-muted-foreground">View your direct referrals and earnings</p>
          </CardContent>
        </Card>

        <Card className="hover-elevate cursor-pointer transition-shadow" data-testid="card-action-binary">
          <CardContent className="pt-6">
            <Network className="h-10 w-10 text-primary mb-3" />
            <h4 className="font-semibold mb-2">Binary Tree</h4>
            <p className="text-sm text-muted-foreground">Track your binary team growth</p>
          </CardContent>
        </Card>

        <Card className="hover-elevate cursor-pointer transition-shadow" data-testid="card-action-matrix">
          <CardContent className="pt-6">
            <TrendingUp className="h-10 w-10 text-primary mb-3" />
            <h4 className="font-semibold mb-2">Matrix Levels</h4>
            <p className="text-sm text-muted-foreground">Monitor your matrix placements</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
