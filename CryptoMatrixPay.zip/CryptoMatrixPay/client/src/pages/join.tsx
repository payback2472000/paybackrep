import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Clock, QrCode, CreditCard, Smartphone, Bitcoin, Copy, Upload, CheckCircle2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Payment } from "@shared/schema";

export default function Join() {
  const { toast } = useToast();
  const [selectedPayment, setSelectedPayment] = useState<string | null>(null);

  const { data: payments = [] } = useQuery<Payment[]>({
    queryKey: ["/api/payments"],
  });

  const submitPaymentMutation = useMutation({
    mutationFn: async (data: { paymentId: string; transactionId: string; proofUrl?: string; method: string }) => {
      return await apiRequest("POST", "/api/payments/submit", data);
    },
    onSuccess: (data: any) => {
      if (data.verified) {
        toast({
          title: "✅ Payment Verified!",
          description: "Your USDT BEP-20 payment has been confirmed on BSC blockchain",
        });
      } else if (data.verified === false) {
        toast({
          title: "⏳ Verification Pending",
          description: data.message || "Transaction not yet confirmed on BSC blockchain. We'll keep checking.",
        });
      } else {
        toast({
          title: "Payment Submitted",
          description: "Your payment has been submitted for verification",
        });
      }
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
    },
  });

  const confirmedPayments = payments.filter(p => p.status === 'confirmed').length;
  const totalPayments = 8; // referral, binary, 5 matrix levels, system fee
  const progress = (confirmedPayments / totalPayments) * 100;

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: "default" | "secondary" | "destructive" | "outline", label: string }> = {
      unpaid: { variant: "outline", label: "Unpaid" },
      pending: { variant: "secondary", label: "Pending" },
      verifying: { variant: "default", label: "Verifying" },
      confirmed: { variant: "default", label: "Confirmed" },
      expired: { variant: "destructive", label: "Expired" },
      disputed: { variant: "destructive", label: "Disputed" },
    };
    const config = variants[status] || variants.unpaid;
    return <Badge variant={config.variant} data-testid={`badge-${status}`}>{config.label}</Badge>;
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied!", description: `${label} copied to clipboard` });
  };

  const [transactionId, setTransactionId] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [method, setMethod] = useState("qr");

  const renderPaymentForm = (payment: Payment) => {
    const handleSubmit = () => {
      submitPaymentMutation.mutate({
        paymentId: payment.id,
        transactionId,
        method,
        proofUrl: file ? URL.createObjectURL(file) : undefined,
      });
      // Reset form
      setTransactionId("");
      setFile(null);
    };

    return (
      <div className="space-y-6">
        <Tabs value={method} onValueChange={setMethod} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="qr" data-testid="tab-qr">
              <QrCode className="h-4 w-4 mr-2" />
              QR Code
            </TabsTrigger>
            <TabsTrigger value="bank" data-testid="tab-bank">
              <CreditCard className="h-4 w-4 mr-2" />
              Bank
            </TabsTrigger>
            <TabsTrigger value="upi" data-testid="tab-upi">
              <Smartphone className="h-4 w-4 mr-2" />
              UPI
            </TabsTrigger>
            <TabsTrigger value="usdt" data-testid="tab-usdt">
              <Bitcoin className="h-4 w-4 mr-2" />
              USDT
            </TabsTrigger>
          </TabsList>

          <TabsContent value="qr" className="space-y-4 mt-4">
            <div className="bg-muted p-6 rounded-lg text-center">
              <div className="w-48 h-48 bg-white mx-auto mb-4 flex items-center justify-center rounded-lg">
                <QrCode className="h-32 w-32 text-muted-foreground" />
              </div>
              <p className="text-sm text-muted-foreground">Scan QR code to pay ₹{payment.amount}</p>
            </div>
          </TabsContent>

          <TabsContent value="bank" className="space-y-4 mt-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between p-3 bg-muted rounded-md">
                <span className="text-sm">Account: 1234567890</span>
                <Button variant="ghost" size="sm" onClick={() => copyToClipboard("1234567890", "Account number")}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted rounded-md">
                <span className="text-sm">IFSC: HDFC0001234</span>
                <Button variant="ghost" size="sm" onClick={() => copyToClipboard("HDFC0001234", "IFSC code")}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="upi" className="space-y-4 mt-4">
            <div className="flex items-center justify-between p-3 bg-muted rounded-md">
              <span className="text-sm font-mono">receiver@upi</span>
              <Button variant="ghost" size="sm" onClick={() => copyToClipboard("receiver@upi", "UPI ID")}>
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="usdt" className="space-y-4 mt-4">
            <div className="space-y-3">
              <div className="p-3 bg-primary/10 rounded-md border border-primary/20">
                <p className="text-sm font-semibold mb-1">Network: Binance Smart Chain (BEP-20)</p>
                <p className="text-xs text-muted-foreground">Make sure to send USDT on BSC network only</p>
              </div>
              <div className="flex items-center justify-between p-3 bg-muted rounded-md">
                <span className="text-sm font-mono">0x...address</span>
                <Button variant="ghost" size="sm" onClick={() => copyToClipboard("0x...address", "USDT BEP-20 address")}>
                  <Copy className="h-4 w-4" />
                </Button>
              </div>
              <div className="p-3 bg-warning/10 rounded-md border border-warning/20">
                <div className="flex items-center justify-between">
                  <p className="text-sm">
                    <span className="font-semibold">Send exactly:</span> {payment.cryptoAmount || (payment.amount === '500' ? '5.00123' : payment.amount === '1000' ? '10.00145' : `${(parseFloat(payment.amount) / 100).toFixed(5)}`)} USDT
                  </p>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => copyToClipboard(payment.cryptoAmount || `${(parseFloat(payment.amount) / 100).toFixed(5)}`, "USDT amount")}
                    data-testid="button-copy-usdt-amount"
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground mt-1">Use exact unique amount for auto-verification</p>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Clock className="h-4 w-4" />
          <span>Time remaining: 23:45:12</span>
        </div>

        <div className="space-y-4">
          <div>
            <Label htmlFor="transaction-id">{method === "usdt" ? "Transaction Hash" : "Transaction ID"}</Label>
            <Input
              id="transaction-id"
              value={transactionId}
              onChange={(e) => setTransactionId(e.target.value)}
              placeholder={method === "usdt" ? "Enter BSC transaction hash (0x...)" : "Enter transaction ID"}
              data-testid="input-transaction-id"
            />
            {method === "usdt" && (
              <p className="text-xs text-muted-foreground mt-1">
                Paste your BSC transaction hash for instant verification
              </p>
            )}
          </div>

          {method !== "usdt" && (
            <div>
              <Label htmlFor="payment-proof">Upload Payment Proof</Label>
              <label htmlFor="payment-proof" className="mt-2 border-2 border-dashed rounded-lg p-6 text-center hover-elevate cursor-pointer block">
                <Upload className="h-10 w-10 mx-auto mb-2 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  {file ? `Selected: ${file.name}` : "Click to upload or drag and drop"}
                </p>
                <input
                  id="payment-proof"
                  type="file"
                  className="hidden"
                  onChange={(e) => setFile(e.target.files?.[0] || null)}
                  data-testid="input-payment-proof"
                  accept="image/*"
                />
              </label>
            </div>
          )}

          <Button
            className="w-full"
            onClick={handleSubmit}
            disabled={!transactionId || submitPaymentMutation.isPending}
            data-testid="button-submit-payment"
          >
            {submitPaymentMutation.isPending ? "Submitting..." : method === "usdt" ? "Submit & Auto-Verify" : "Submit for Verification"}
          </Button>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-headline-md font-display mb-2">Account Activation</h2>
        <p className="text-muted-foreground">Complete all payments to activate your account</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Activation Progress</CardTitle>
          <CardDescription>{confirmedPayments} of {totalPayments} payments completed</CardDescription>
        </CardHeader>
        <CardContent>
          <Progress value={progress} className="h-2" data-testid="progress-activation" />
        </CardContent>
      </Card>

      <Accordion type="single" collapsible className="space-y-4">
        {payments.map((payment, index) => (
          <AccordionItem
            key={payment.id}
            value={payment.id}
            className="border rounded-lg px-4"
            data-testid={`payment-card-${index}`}
          >
            <AccordionTrigger className="hover:no-underline">
              <div className="flex items-center justify-between w-full pr-4">
                <div className="flex items-center gap-4">
                  <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10 text-primary font-semibold">
                    {index + 1}
                  </div>
                  <div className="text-left">
                    <h4 className="font-semibold">{payment.paymentType.replace(/_/g, ' ').toUpperCase()}</h4>
                    <p className="text-sm text-muted-foreground">₹{payment.amount}</p>
                  </div>
                </div>
                {getStatusBadge(payment.status)}
              </div>
            </AccordionTrigger>
            <AccordionContent>
              {payment.status === 'unpaid' && renderPaymentForm(payment)}
              {payment.status === 'confirmed' && (
                <div className="flex items-center gap-2 p-4 bg-success/10 rounded-lg">
                  <CheckCircle2 className="h-5 w-5 text-success" />
                  <span className="text-sm font-medium">Payment confirmed</span>
                </div>
              )}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}
